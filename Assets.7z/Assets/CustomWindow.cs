using UnityEditor;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.Requests;
using UnityEngine;

//https://docs.unity.cn/cn/2020.3/Manual/upm-api.html
[InitializeOnLoad]
public class CustomWindow : EditorWindow
{
    //static CustomWindow()
    //{
    //    // ��Unity�༭������ʱ���Զ��崰��
    //    EditorApplication.delayCall += OpenWindow;
    //}

    //[MenuItem("Window/Custom Window")]
    //private static void OpenWindow()
    //{
    //    // ��������ʾ�Զ��崰��
    //    CustomWindow window = GetWindow<CustomWindow>();
    //    window.titleContent = new GUIContent("Custom Window");
    //    window.Show();
    //}

    //private void OnGUI()
    //{
    //    // �ڴ����л���GUIԪ��
    //    GUILayout.Label("Hello, Custom Window!");
    //}

    static AddRequest Request;
    [MenuItem("��װ��/Install Package from Git URL")]
    private static void InstallPackageFromGitURL()
    {
        //string gitURL = "https://github.com/Cysharp/UniTask.git?path=src/UniTask/Assets/Plugins/UniTask";
        string gitURL = "com.tuyoogame.yooasset";
        // ��װ��
        Request = Client.Add(gitURL);
        EditorApplication.update += Progress;
    }

    static void Progress()
    {
        if (Request.IsCompleted)
        {
            if (Request.Status == StatusCode.Success)
                Debug.Log($"���سɹ�Package name: {Request.Result.name}");
            else if (Request.Status >= StatusCode.Failure)
                Debug.Log(Request.Error.message);
            EditorApplication.update -= Progress;
        }
    }
}