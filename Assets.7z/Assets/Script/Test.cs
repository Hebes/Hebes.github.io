using Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    void Start()
    {
        CoreResource resource = new CoreResource();
        resource.ICoreInit();

        for (int i = 0; i < 100; i++)
        {
            GameObject gameObject = CoreResource.Load<GameObject>("Cube");
            //GameObject.Instantiate(gameObject);
        }
    }
}
