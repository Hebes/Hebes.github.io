﻿/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    数据接口

-----------------------*/

namespace Core
{
    public interface IData
    {
        public abstract int GetId();
    }
}
