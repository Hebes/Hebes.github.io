﻿using Cysharp.Threading.Tasks;
using System.Collections.Generic;

/*--------脚本描述-----------

描述:
    数据加载管理

-----------------------*/

namespace Core
{
    public class CoreData : ICore
    {
        public static CoreData Instance;
        private Dictionary<string, List<IData>> bytesDataDic;//数据

        public void ICoreInit()
        {
            Instance = this;
            bytesDataDic = new Dictionary<string, List<IData>>();
            Debug.Log("数据初始化完毕");
        }

        public static void InitData<T>(string filePath) where T : IData
        {
            byte[] fileData = CoreResource.LoadByteData(filePath);
            List<IData> itemDetailsList = BinaryAnalysis.GetData<T>(fileData);
            if (Instance.bytesDataDic.ContainsKey(typeof(T).FullName))
                Instance.bytesDataDic[typeof(T).FullName] = itemDetailsList;
            Instance.bytesDataDic.Add(typeof(T).FullName, itemDetailsList);
        }


        /// <summary>
        /// 获取一条数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public static T GetDataOne<T>(int id) where T : class, IData
        {
            if (!Instance.bytesDataDic.ContainsKey(typeof(T).FullName))
            {
                Debug.Log($"未能找到数据请先初始化{typeof(T).FullName}");
                return null;
            }

            IData data = Instance.bytesDataDic[typeof(T).FullName].Find(data => 
            { 
                return data.GetId() == id; 
            });
            return data == null ? null : data as T;
        }

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static List<IData> GetDataList<T>() where T : class, IData
        {
            if (!Instance.bytesDataDic.ContainsKey(typeof(T).FullName))
            {
                Debug.Log($"未能找到数据请先初始化{typeof(T).FullName}");
                return null;
            }

            List<IData> dataListTemp = Instance.bytesDataDic[typeof(T).FullName];
            return dataListTemp;
        }

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static List<T> GetDataListAsT<T>() where T : class, IData
        {
            List<T> dataListTemp = new List<T>();
            if (!Instance.bytesDataDic.ContainsKey(typeof(T).FullName))
            {
                Debug.Log($"未能找到数据请先初始化{typeof(T).FullName}");
                return null;
            }
            foreach (IData item in Instance.bytesDataDic[typeof(T).FullName])
                dataListTemp.Add(item as T);
            return dataListTemp;
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        public static void RemoveData(string dataKey)
        {
            if (Instance.bytesDataDic.TryGetValue(dataKey, out List<IData> datas))
                Instance.bytesDataDic[dataKey] = null;
        }
    }
}
