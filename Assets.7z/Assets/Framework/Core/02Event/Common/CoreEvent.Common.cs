﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*--------脚本描述-----------

描述:
    普通事件

-----------------------*/

namespace Core
{
    public partial class CoreEvent
    {
        public static void EventAdd(string eventName, EventInfoCommon.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon(commonAction));
        }
        public static void EventRemove(string eventName, EventInfoCommon.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon).commonAction -= commonAction;
        }
        public static void EventTrigger(string eventName)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon).Trigger();//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }


        public static void EventAdd<T>(string eventName, EventInfoCommon<T>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T>).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon<T>(commonAction));
        }
        public static void EventRemove<T>(string eventName, EventInfoCommon<T>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T>).commonAction -= commonAction;
        }
        public static void EventTrigger<T>(string eventName, T t)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T>).Trigger(t);//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }


        public static void EventAdd<T, K>(string eventName, EventInfoCommon<T, K>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K>).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon<T, K>(commonAction));
        }
        public static void EventRemove<T, K>(string eventName, EventInfoCommon<T, K>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K>).commonAction -= commonAction;
        }
        public static void EventTrigger<T, K>(string eventName, T t, K k)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K>).Trigger(t, k);//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }


        public static void EventAdd<T, K, V>(string eventName, EventInfoCommon<T, K, V>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V>).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon<T, K, V>(commonAction));
        }
        public static void EventRemove<T, K, V>(string eventName, EventInfoCommon<T, K, V>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V>).commonAction -= commonAction;
        }
        public static void EventTrigger<T, K, V>(string eventName, T t, K k, V v)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V>).Trigger(t, k, v);//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }

        public static void EventAdd<T, K, V, N>(string eventName, EventInfoCommon<T, K, V, N>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N>).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon<T, K, V, N>(commonAction));
        }
        public static void EventRemove<T, K, V, N>(string eventName, EventInfoCommon<T, K, V, N>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N>).commonAction -= commonAction;
        }
        public static void EventTrigger<T, K, V, N>(string eventName, T t, K k, V v, N n)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N>).Trigger(t, k, v, n);//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }


        public static void EventAdd<T, K, V, N, M>(string eventName, EventInfoCommon<T, K, V, N, M>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N, M>).commonAction += commonAction;
            else
                Instance.eventDic.Add(eventName, new EventInfoCommon<T, K, V, N, M>(commonAction));
        }
        public static void EventRemove<T, K, V, N, M>(string eventName, EventInfoCommon<T, K, V, N, M>.CommonEvent commonAction)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N, M>).commonAction -= commonAction;
        }
        public static void EventTrigger<T, K, V, N, M>(string eventName, T t, K k, V v, N n, M m)
        {
            if (Instance.eventDic.TryGetValue(eventName, out IEventInfo eventInfo))
                (eventInfo as EventInfoCommon<T, K, V, N, M>).Trigger(t, k, v, n, m);//如果显示空指针异常,请检查监听的参数和触发的参数是否一致
        }
    }
}
