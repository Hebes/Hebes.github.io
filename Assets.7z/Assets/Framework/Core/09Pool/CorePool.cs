﻿using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    对象池模块

-----------------------*/


namespace Core
{

    public class CorePool : ICore
    {
        public static CorePool Instance;
        public Dictionary<string, PoolData> poolDic;
        private GameObject poolObj;

        public void ICoreInit()
        {
            Instance = this;
            poolDic = new Dictionary<string, PoolData>();
            poolObj = new GameObject("Pool");
        }


        /// <summary>
        /// 往外拿东西
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public void GetObj(string name, UnityAction<GameObject> callBack)
        {
            //有抽屉 并且抽屉里有东西
            if (poolDic.ContainsKey(name) && poolDic[name].poolList.Count > 0)
            {
                callBack?.Invoke(poolDic[name].GetObj());
                return;
            }
            GameObject go = CoreResource.Load<GameObject>(name);
            go.name = name;
            callBack?.Invoke(go);
        }

        public void GetObj(string name, Transform parent, UnityAction<GameObject> callBack)
        {
            //有抽屉 并且抽屉里有东西
            if (poolDic.ContainsKey(name) && poolDic[name].poolList.Count > 0)
            {
                callBack?.Invoke(poolDic[name].GetObj());
                return;
            }
            GameObject go = CoreResource.Load<GameObject>(name);
            GameObject.Instantiate(go, parent);
            go.name = name;
            callBack?.Invoke(go);
        }

        public async UniTask<GameObject> GetObjAsync(string name, Transform parent)
        {
            //有抽屉 并且抽屉里有东西
            if (poolDic.TryGetValue(name, out PoolData poolData))
                return poolData.GetObj();
            GameObject go = await CoreResource.LoadAsync<GameObject>(name);
            go.name = name;
            return go;
        }

        /// <summary>
        /// 换暂时不用的东西给我
        /// </summary>
        public void PushObj(string name, GameObject obj)
        {
            if (poolDic.TryGetValue(name, out PoolData poolData))
            {
                poolData.PushObj(obj);
                return;
            }
            poolDic.Add(name, new PoolData(obj, poolObj));
        }

        /// <summary>
        /// 清空缓存池的方法 
        /// 主要用在 场景切换时
        /// </summary>
        public void Clear()
        {
            foreach (var Key in poolDic.Keys)
                poolDic[Key].poolList.ForEach((go) => { GameObject.Destroy(go); });
            poolDic.Clear();
            poolObj = null;
        }
    }
}
