﻿using UnityEngine;
using UnityEngine.UI;

namespace Core
{
    public static class ExpansionButton
    {
        public static Button GetButton(this GameObject gameObject)
        {
            return gameObject.GetComponent<Button>();
        }
        public static Button GetButton(this Transform transform)
        {
            return transform.GetComponent<Button>();
        }
    }
}
