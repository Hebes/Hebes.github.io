using System.Collections.Generic;

namespace ExcelDataReader.Core.OpenXmlFormat
{
    /// <summary>
    /// Shared string table.
    /// </summary>
    internal sealed class XlsxSST : List<string>
    {
    }
}
