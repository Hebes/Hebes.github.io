﻿namespace ExcelDataReader.Core.NumberFormat
{
    internal sealed class Condition
    {
        public string Operator { get; set; }

        public double Value { get; set; }
    }
}
