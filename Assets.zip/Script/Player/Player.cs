﻿using System;
using UnityEngine;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	玩家控制脚本

-----------------------*/

namespace Farm2D
{

    [RequireComponent(typeof(Rigidbody2D))]
    [RequireComponent(typeof(BoxCollider2D))]
    [RequireComponent(typeof(PlayerAnimations))]
    public class Player : MonoBehaviour
    {
        private PlayerAnimations playerAnimations;

        private void Awake()
        {
            //GetComponent<Rigidbody2D>();
            //GetComponent<BoxCollider2D>();
        }
    }
}
