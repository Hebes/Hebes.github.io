﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	玩家动画

-----------------------*/

namespace Farm2D
{
    public class PlayerAnimations : MonoBehaviour
    {

    }
}
