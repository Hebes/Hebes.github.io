﻿/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	库存物体

-----------------------*/

namespace Farm2D
{
    public struct InventoryItem
    {
        /// <summary>
        /// 物体ID
        /// </summary>
        public int itemID;

        /// <summary>
        /// 物品数量
        /// </summary>
        public int itemQuantity;
    }
}
