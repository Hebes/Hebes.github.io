﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	背包配置文件

-----------------------*/

namespace Farm2D
{
    public enum ConfigInventory
    {
        /// <summary> 场景卸载前需要做的事情 </summary>
        EventBeforeSceneUnload = 1,

        /// <summary> 场景加载后需要做的事情 </summary>
        EventAfterSceneLoaded = 2,
    }
}
