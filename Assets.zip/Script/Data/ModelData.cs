﻿using Cysharp.Threading.Tasks;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	初始化数据

-----------------------*/

namespace Farm2D
{
    public class ModelData : IModelInit
    {
        public void  ModelInit()
        {

        }
    }
}
