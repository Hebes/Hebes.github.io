﻿using Core;
using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;
using Debug = Core.Debug;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	初始化游戏

-----------------------*/

namespace Farm2D
{
    public class InitGame
    {
        public InitGame()
        {
            //TODO 后面可能准备跟新回合制
            //TODO 游玩机制：玩家种田,田里可以种出材料 合成技能，战斗仿照最终幻想4游戏，怪物可以捕捉 可以学习技能  战斗中技能可以复合创造新技能,有冒险者协会
            //TODO 编写初始化模块代码
            Init().Forget();
        }

        /// <summary>
        /// 初始化
        /// </summary>
        /// <returns></returns>
        private async UniTask Init()
        {
            await CoreInit();
            await InitModel();
        }

        /// <summary>
        /// 核心初始化
        /// </summary>
        /// <returns></returns>
        private async UniTask CoreInit()
        {
            List<ICore> cores = new List<ICore>();
            cores.Add(new CoreDebug());         //日志模块
            cores.Add(new CoreEvent());         //事件模块
            cores.Add(new CoreMono());          //mono模块
            cores.Add(new CoreResource());          //资源加载模块
            cores.Add(new CoreAduio());          //音频模块
            //cores.Add(new CoreUI());          //Ui模块
            //cores.Add(new CoreData());          //数据模块
            //cores.Add(new CoreScene());          //场景模块
            for (int i = 0; i < cores.Count; i++)
            {
                cores[i].ICoreInit();
                await UniTask.Yield();
            }
        }

        /// <summary>
        /// 初始化子模块
        /// </summary>
        /// <returns></returns>
        private async UniTask InitModel()
        {
            List<IModelInit> list = new List<IModelInit>();
            list.Add(new ModelData());          //初始化数据
            list.Add(new ModelInventory());     //初始化管理系统
            for (int i = 0; i < list.Count; i++)
            {
                list[i].ModelInit();
                await UniTask.Yield();
            }
        }
    }
}
