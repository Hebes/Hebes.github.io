﻿using Cysharp.Threading.Tasks;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	保存或者加载记录

-----------------------*/

namespace Farm2D
{
    public class ModelSaveOrLoad : IModelInit
    {
        public static ModelSaveOrLoad Instance;

        public void ModelInit()
        {
            Instance = this;
        }
    }
}
