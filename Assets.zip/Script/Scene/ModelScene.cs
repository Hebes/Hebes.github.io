﻿using Core;
using Cysharp.Threading.Tasks;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	用于切换场景的

-----------------------*/

namespace Farm2D
{
    public class ModelScene : IModelInit
    {
        public static ModelScene Instance { get; private set; }
        public void ModelInit()
        {
            Instance = this;
        }

        /// <summary>
        /// 第一次加载场景
        /// </summary>
        private async UniTask NewGameScene()
        {
            await UniTask.Yield();
        }


        /// <summary>
        /// 切换场景
        /// </summary>
        public async UniTask SwitchScene(string targetScene, ELoadSceneModel loadSceneModel)
        {
            CoreEvent.EventTrigger((int)ConfigInventory.EventBeforeSceneUnload);//场景卸载前需要做的事情
            await CoreScene.LoadSceneAsync(targetScene, loadSceneModel);   //加载场景
            CoreEvent.EventTrigger((int)ConfigInventory.EventAfterSceneLoaded);//场景加载后需要做的事情
        }
    }
}
