
public class StreamingAssetsDefine
{
	public const string RootFolderName = "yoo";
}