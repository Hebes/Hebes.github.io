﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	多语言组件

-----------------------*/

namespace Farm2D
{
    public class LanguageText : MonoBehaviour
    {
        public string key = "错误";
        private TMP_Text m_MeshText;

        private void Awake()
        {
            m_MeshText = GetComponent<TMP_Text>();
        }

        private void OnEnable()
        {
            OnSwitchLanguage();
            ModelLanaguage.Instance.OnLanguageChangeEvt += OnSwitchLanguage;
        }

        private void OnDisable()
        {
            ModelLanaguage.Instance.OnLanguageChangeEvt -= OnSwitchLanguage;
        }

        private void OnSwitchLanguage()
        {
            if (m_MeshText != null)
            {
                m_MeshText.text = ModelLanaguage.Instance.GetText(key);
                m_MeshText.font = ModelLanaguage.Instance.font;
            }
        }

        /// <summary>
        /// 设置Key和切换语言
        /// </summary>
        /// <param name="key">关键词</param>
        public void OnSetKeyAndChange(string key)
        {
            this.key = key;
            OnSwitchLanguage();
        }
    }
}
