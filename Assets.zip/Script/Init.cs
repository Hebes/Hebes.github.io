﻿using Cysharp.Threading.Tasks;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Text;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;
using YooAsset;
using Debug = UnityEngine.Debug;


/*--------脚本描述-----------

电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
	初始化游戏

-----------------------*/

namespace Farm2D
{
    /// <summary> YooAsset流程状态 </summary>
    public enum EProcess
    {
        /// <summary> 流程错误跳出 </summary>
        FsmErrorPrepare,
        /// <summary> 流程准备工作 </summary>
        FsmPatchPrepare,
        /// <summary> 检查版本XML配置文件 </summary>
        FsmVersionXMLPrepare,
        /// <summary> 初始化资源包 </summary>
        FsmInitialize,
        /// <summary> 更新资源版本号 </summary>
        FsmUpdateVersion,
        /// <summary> 更新资源清单 </summary>
        FsmUpdatePackageManifest,
        /// <summary> 创建文件下载器 </summary>
        FsmCreatePackageDownloader,
        /// <summary> 下载更新文件 </summary>
        FsmDownloadFiles,
        /// <summary> 清理未使用的缓存文件 </summary>
        FsmClearCache,
        /// <summary> 流程更新完毕 </summary>
        FsmPatchDone,
    }

    public class Init : MonoBehaviour
    {
        public bool unityLoad = true;

        //TODO 需要测试

        //Yooasset相关
        public EPlayMode playMode = EPlayMode.EditorSimulateMode;           //资源系统运行模式
        private EProcess CurrentProcess;                                    //当前所在的流程
        private ResourcePackage package;                                    //Yooasset资源包
        private string version;                                             //跟新版本
        private ResourceDownloaderOperation downloader;                     //下载器

        private void Awake()
        {
            if (unityLoad)
                new InitGame();
            else
                SwitchProcessModel(EProcess.FsmPatchPrepare);
        }



        /// <summary>
        /// 切换Yooasset流程模式
        /// </summary>
        private void SwitchProcessModel(EProcess HotUpdateProcess)
        {
            switch (HotUpdateProcess)
            {
                case EProcess.FsmErrorPrepare: StartCoroutine(nameof(FsmErrorPrepare)); break;
                case EProcess.FsmPatchPrepare: StartCoroutine(nameof(FsmPatchPrepare)); break;
                case EProcess.FsmVersionXMLPrepare: StartCoroutine(nameof(FsmVersionXMLPrepare)); break;
                case EProcess.FsmInitialize: StartCoroutine(nameof(FsmInitialize)); break;
                case EProcess.FsmUpdateVersion: StartCoroutine(nameof(FsmUpdateVersion)); break;
                case EProcess.FsmUpdatePackageManifest: StartCoroutine(nameof(FsmUpdatePackageManifest)); break;
                case EProcess.FsmCreatePackageDownloader: StartCoroutine(nameof(FsmCreatePackageDownloader)); break;
                case EProcess.FsmDownloadFiles: StartCoroutine(nameof(FsmDownloadFiles)); break;
                case EProcess.FsmClearCache: StartCoroutine(nameof(FsmClearCache)); break;
                case EProcess.FsmPatchDone: StartCoroutine(nameof(FsmPatchDone)); break;
            }
        }

        /// <summary>
        /// 流程错误跳出
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmErrorPrepare()
        {
            Debug.LogError($"结束中断,中断点:{CurrentProcess}");
            Debug.LogError($"流程错误跳出");
            yield break;
        }

        /// <summary>
        /// 流程准备工作
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmPatchPrepare()
        {
            yield return null;
            Debug.Log("流程准备工作");
            // 初始化资源系统
            YooAssets.Initialize();
            YooAssets.SetOperationSystemMaxTimeSlice(30);//设置异步系统参数，每帧执行消耗的最大时间切片
            SwitchProcessModel(EProcess.FsmVersionXMLPrepare);
        }

        /// <summary>
        /// 下载更新检查版本XML配置文件
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmVersionXMLPrepare()
        {
            yield return null;
            if (playMode == EPlayMode.HostPlayMode)
            {
                //TODO 需要添加判断如果没下载成功的话
            }
            //进入初始资源流程
            SwitchProcessModel(EProcess.FsmInitialize);
        }

        private IEnumerator FsmInitialize()
        {
            yield return null;
            Debug.Log("初始化资源包");

            //资源包
            package = YooAssets.TryGetPackage(ConfigCore.YooAseetPackage);
            if (package == null)
                package = YooAssets.CreatePackage(ConfigCore.YooAseetPackage);

            // 设置该资源包为默认的资源包，可以使用YooAssets相关加载接口加载该资源包内容。
            YooAssets.SetDefaultPackage(package);

            // 编辑器下的模拟模式
            InitializationOperation initializationOperation = null;
            if (playMode == EPlayMode.EditorSimulateMode)
            {
                var createParameters = new EditorSimulateModeParameters();
                createParameters.SimulateManifestFilePath = EditorSimulateModeHelper.SimulateBuild(EDefaultBuildPipeline.BuiltinBuildPipeline, ConfigCore.YooAseetPackage);
                initializationOperation = package.InitializeAsync(createParameters);
            }

            // 单机运行模式
            if (playMode == EPlayMode.OfflinePlayMode)
            {
                var createParameters = new OfflinePlayModeParameters();
                createParameters.DecryptionServices = new FileStreamDecryption();
                initializationOperation = package.InitializeAsync(createParameters);
            }

            // 联机运行模式
            if (playMode == EPlayMode.HostPlayMode)
            {
                string defaultHostServer = GetHostServerURL();
                string fallbackHostServer = GetHostServerURL();
                var createParameters = new HostPlayModeParameters();
                createParameters.DecryptionServices = new FileStreamDecryption();
                createParameters.BuildinQueryServices = new GameQueryServices();
                createParameters.RemoteServices = new RemoteServices(defaultHostServer, fallbackHostServer);
                initializationOperation = package.InitializeAsync(createParameters);
            }

            // WebGL运行模式
            if (playMode == EPlayMode.WebPlayMode)
            {
                string defaultHostServer = GetHostServerURL();
                string fallbackHostServer = GetHostServerURL();
                var createParameters = new WebPlayModeParameters();
                createParameters.DecryptionServices = new FileStreamDecryption();
                createParameters.BuildinQueryServices = new GameQueryServices();
                createParameters.RemoteServices = new RemoteServices(defaultHostServer, fallbackHostServer);
                initializationOperation = package.InitializeAsync(createParameters);
            }
            yield return initializationOperation;

            // 如果初始化失败弹出提示界面
            if (initializationOperation.Status != EOperationStatus.Succeed)
            {
                Debug.LogWarning($"{initializationOperation.Error}");
                SwitchProcessModel(EProcess.FsmErrorPrepare);
            }
            else
            {
                version = package.GetPackageVersion();
                Debug.Log($"资源包初始化成功,Init资源包版本 : {version}");
                SwitchProcessModel(EProcess.FsmUpdateVersion);
            }
        }

        /// <summary>
        /// 更新资源版本号
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmUpdateVersion()
        {
            yield return new WaitForSecondsRealtime(0.5f);

            var operation = package.UpdatePackageVersionAsync();
            yield return operation;

            if (operation.Status != EOperationStatus.Succeed)
            {
                Debug.LogWarning(operation.Error);
                SwitchProcessModel(EProcess.FsmErrorPrepare);
            }
            else
            {
                Debug.Log($"当前版本{operation.PackageVersion}");
                SwitchProcessModel(EProcess.FsmUpdatePackageManifest);
            }
        }

        /// <summary>
        /// 更新资源清单
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmUpdatePackageManifest()
        {
            yield return new WaitForSecondsRealtime(0.5f);

            bool savePackageVersion = true;
            var operation = package.UpdatePackageManifestAsync(version, savePackageVersion);
            yield return operation;

            if (operation.Status != EOperationStatus.Succeed)
            {
                Debug.LogWarning(operation.Error);
                SwitchProcessModel(EProcess.FsmErrorPrepare);
            }
            else
            {
                SwitchProcessModel(EProcess.FsmCreatePackageDownloader);
            }
        }

        /// <summary>
        /// 创建文件下载器
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmCreatePackageDownloader()
        {
            yield return new WaitForSecondsRealtime(0.5f);

            int downloadingMaxNum = 10;
            int failedTryAgain = 3;
            downloader = package.CreateResourceDownloader(downloadingMaxNum, failedTryAgain);

            if (downloader.TotalDownloadCount == 0)
            {
                Debug.Log("没有找到任何下载文件!");
                SwitchProcessModel(EProcess.FsmPatchDone);
            }
            else
            {
                // 发现新更新文件后，挂起流程系统
                // 注意：开发者需要在下载前检测磁盘空间不足
                int totalDownloadCount = downloader.TotalDownloadCount;
                long totalDownloadBytes = downloader.TotalDownloadBytes;
                Debug.Log($"当前下载总数{totalDownloadCount},当前下载字节{totalDownloadBytes}Bytes");
                SwitchProcessModel(EProcess.FsmDownloadFiles);
            }
        }

        /// <summary>
        /// 下载更新文件
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmDownloadFiles()
        {
            yield return null;
            //注册回调方法
            downloader.OnStartDownloadFileCallback = OnStartDownloadFileFunction;
            downloader.OnDownloadErrorCallback = OnDownloadErrorFunction;
            downloader.OnDownloadProgressCallback = OnDownloadProgressUpdateFunction;
            downloader.OnDownloadOverCallback = OnDownloadOverFunction;
            //开启下载
            downloader.BeginDownload();
            yield return downloader;

            //检测下载结果
            if (downloader.Status != EOperationStatus.Succeed)
            {
                Debug.LogError($"更新失败！{downloader.Error}");
                SwitchProcessModel(EProcess.FsmErrorPrepare);
            }
            else
            {
                Debug.Log("更新完成!");
                SwitchProcessModel(EProcess.FsmClearCache);
            }
        }

        private IEnumerator FsmClearCache()
        {
            yield return null;
            var operation = package.ClearUnusedCacheFilesAsync();
            operation.Completed += OnClearCacheFunction;
            SwitchProcessModel(EProcess.FsmPatchDone);
        }

        /// <summary>
        /// 更新完毕
        /// </summary>
        /// <returns></returns>
        private IEnumerator FsmPatchDone()
        {
            yield return null;
            Debug.Log("流程更新完毕");
            new InitGame();
        }

        /// <summary>
        /// 获取资源服务器地址
        /// </summary>
        private string GetHostServerURL()
        {
            //string hostServerIP = "http://10.0.2.2"; //安卓模拟器地址
            string hostServerIP = "http://127.0.0.1";
            string appVersion = "v1.0";

#if UNITY_EDITOR
            if (UnityEditor.EditorUserBuildSettings.activeBuildTarget == UnityEditor.BuildTarget.Android)
                return $"{hostServerIP}/CDN/Android/{appVersion}";
            else if (UnityEditor.EditorUserBuildSettings.activeBuildTarget == UnityEditor.BuildTarget.iOS)
                return $"{hostServerIP}/CDN/IPhone/{appVersion}";
            else if (UnityEditor.EditorUserBuildSettings.activeBuildTarget == UnityEditor.BuildTarget.WebGL)
                return $"{hostServerIP}/CDN/WebGL/{appVersion}";
            else
                return $"{hostServerIP}/CDN/PC/{appVersion}";
#else
		if (Application.platform == RuntimePlatform.Android)
			return $"{hostServerIP}/CDN/Android/{appVersion}";
		else if (Application.platform == RuntimePlatform.IPhonePlayer)
			return $"{hostServerIP}/CDN/IPhone/{appVersion}";
		else if (Application.platform == RuntimePlatform.WebGLPlayer)
			return $"{hostServerIP}/CDN/WebGL/{appVersion}";
		else
			return $"{hostServerIP}/CDN/PC/{appVersion}";
#endif
        }

        //回调
        /// <summary>
        /// 更新中
        /// </summary>
        /// <param name="totalDownloadCount"></param>
        /// <param name="currentDownloadCount"></param>
        /// <param name="totalDownloadBytes"></param>
        /// <param name="currentDownloadBytes"></param>
        private void OnDownloadProgressUpdateFunction(int totalDownloadCount, int currentDownloadCount, long totalDownloadBytes, long currentDownloadBytes)
        {
            Debug.Log(string.Format("文件总数：{0}, 已下载文件数：{1}, 下载总大小：{2}, 已下载大小：{3}", totalDownloadCount, currentDownloadCount, totalDownloadBytes, currentDownloadBytes));
            //LoadingText.text = string.Format($"文件总数：{totalDownloadCount}, 已下载文件数：{currentDownloadCount}, 下载总大小：{GetMB(totalDownloadBytes)}, 已下载大小：{GetMB(currentDownloadBytes)}");

            //LoadingText.text = string.Format($"已下载文件数：{currentDownloadCount}/{totalDownloadCount}," +
            //    $"已下载大小：{(currentDownloadBytes)}/{(totalDownloadBytes)}");
            Debug.Log("需要下载的:" + currentDownloadBytes);
        }

        /// <summary>
        /// 下载出错
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="error"></param>
        private void OnDownloadErrorFunction(string fileName, string error)
        {
            Debug.LogError(string.Format("下载出错：文件名：{0}, 错误信息：{1}", fileName, error));
            //LoadingText.text = string.Format($"下载出错：文件名：{fileName}, 错误信息：{error}");
        }

        /// <summary>
        /// 开始下载
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="sizeBytes"></param>
        private void OnStartDownloadFileFunction(string fileName, long sizeBytes)
        {
            Debug.Log(string.Format("开始下载：文件名：{0}, 文件大小：{1}", fileName, sizeBytes));
            //LoadingText.text = string.Format($"开始下载：文件名：{fileName}, 文件大小：{GetMB(sizeBytes)}");
            //LoadingText.text = string.Format($"文件大小：{GetMB(sizeBytes)}");
        }

        /// <summary>
        /// 下载完成
        /// </summary>
        /// <param name="isSucceed"></param>
        private void OnDownloadOverFunction(bool isSucceed)
        {
            Debug.Log("下载" + (isSucceed ? "成功" : "失败"));
            //LoadingText.text = $"下载{(isSucceed ? "成功" : "失败")}";
        }

        /// <summary>
        /// 清理缓存
        /// </summary>
        /// <param name="asyncOperationBase"></param>
        private void OnClearCacheFunction(AsyncOperationBase asyncOperationBase)
        {
            Debug.Log("清理缓存完毕,流程更新完毕");
            //LoadingText.text = "清理缓存完毕,流程更新完毕";
        }
    }

    /// <summary>
    /// 远端资源地址查询服务类
    /// </summary>
    public class RemoteServices : IRemoteServices
    {
        private readonly string _defaultHostServer;
        private readonly string _fallbackHostServer;

        public RemoteServices(string defaultHostServer, string fallbackHostServer)
        {
            _defaultHostServer = defaultHostServer;
            _fallbackHostServer = fallbackHostServer;
        }
        string IRemoteServices.GetRemoteMainURL(string fileName)
        {
            return $"{_defaultHostServer}/{fileName}";
        }
        string IRemoteServices.GetRemoteFallbackURL(string fileName)
        {
            return $"{_fallbackHostServer}/{fileName}";
        }
    }

    /// <summary>
	/// 资源文件流加载解密类
	/// </summary>
	public class FileStreamDecryption : IDecryptionServices
    {
        /// <summary>
        /// 同步方式获取解密的资源包对象
        /// 注意：加载流对象在资源包对象释放的时候会自动释放
        /// </summary>
        AssetBundle IDecryptionServices.LoadAssetBundle(DecryptFileInfo fileInfo, out Stream managedStream)
        {
            BundleStream bundleStream = new BundleStream(fileInfo.FileLoadPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            managedStream = bundleStream;
            return AssetBundle.LoadFromStream(bundleStream, fileInfo.ConentCRC, GetManagedReadBufferSize());
        }

        /// <summary>
        /// 异步方式获取解密的资源包对象
        /// 注意：加载流对象在资源包对象释放的时候会自动释放
        /// </summary>
        AssetBundleCreateRequest IDecryptionServices.LoadAssetBundleAsync(DecryptFileInfo fileInfo, out Stream managedStream)
        {
            BundleStream bundleStream = new BundleStream(fileInfo.FileLoadPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            managedStream = bundleStream;
            return AssetBundle.LoadFromStreamAsync(bundleStream, fileInfo.ConentCRC, GetManagedReadBufferSize());
        }

        private static uint GetManagedReadBufferSize()
        {
            return 1024;
        }
    }

    /// <summary>
    /// 资源文件解密流
    /// </summary>
    public class BundleStream : FileStream
    {
        public const byte KEY = 64;

        public BundleStream(string path, FileMode mode, FileAccess access, FileShare share) : base(path, mode, access, share)
        {
        }
        public BundleStream(string path, FileMode mode) : base(path, mode)
        {
        }

        public override int Read(byte[] array, int offset, int count)
        {
            var index = base.Read(array, offset, count);
            for (int i = 0; i < array.Length; i++)
            {
                array[i] ^= KEY;
            }
            return index;
        }
    }
}
