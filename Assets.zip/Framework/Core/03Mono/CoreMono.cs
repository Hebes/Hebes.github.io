﻿using Cysharp.Threading.Tasks;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Time = UnityEngine.Time;


/*--------脚本描述-----------

电子邮箱：
    1607388033@qq.com
作者:
    暗沉
描述:
    Mono模块

-----------------------*/

namespace Core
{
    public enum EMonoType
    {
        Updata,
        FixedUpdate,
    }

    public class CoreMono : ICore
    {
        public static CoreMono Instance;

        /// <summary>
        /// int key请用枚举转
        /// </summary>
        private Dictionary<int, Coroutine> CoroutineDic;

        public void ICoreInit()
        {
            Instance = this;
            CoroutineDic = new Dictionary<int, Coroutine>();
            Debug.Log("初始化Mono完毕!");
        }

        /// <summary>
        /// 暂停
        /// </summary>
        /// <param name="m_Time">0暂停1不暂停</param>
        public void Pause(float m_Time)
        {
            Time.timeScale = m_Time;
        }

        public static void AddMonEvent(EMonoType monoType, UnityAction unityAction)
        {
            MonoController.Instance.AddMonEvent(monoType, unityAction);
        }

        public static void RemoveMonoEvent(EMonoType monoType, UnityAction unityAction)
        {
            MonoController.Instance.RemoveMonoEvent(monoType, unityAction);
        }

        public static void AddCoroutine(int coroutineKey, IEnumerator coroutine)
        {
            if (!Instance.CoroutineDic.ContainsKey(coroutineKey))
                Instance.CoroutineDic.Add(coroutineKey, MonoController.Instance.StartCoroutine(coroutine));
            Debug.Error($"协程已经存在{coroutineKey}");
        }
        public static void StopCoroutine(int coroutineKey)
        {
            if (Instance.CoroutineDic.TryGetValue(coroutineKey, out Coroutine coroutine))
            {
                MonoController.Instance.StopCoroutine(coroutine);
                Instance.CoroutineDic.Remove(coroutineKey);
            }
            Debug.Error("停止失败请，协程不存在");
        }
    }
}
