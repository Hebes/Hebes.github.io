﻿/*--------脚本描述-----------

描述:
	初始化接口

-----------------------*/

public interface IAwake
{
    public void Awake();
}
