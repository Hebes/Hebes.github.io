﻿/*--------脚本描述-----------

电子邮箱：
    1607388033@qq.com
作者:
    暗沉
描述:
    普通事件监听

-----------------------*/

using Farm2D;
using System.Collections.Generic;

namespace Core
{
    public class EventCommon : IEvent
    {
        private List<EventCommonData> commonEventsList;

        public EventCommon(EventCommonData eventCommonData) => commonEventsList = new List<EventCommonData>() { eventCommonData };
        public void Add(EventCommonData eventData) => commonEventsList.Add(eventData);
        public void Remove(EventCommonData eventData) => commonEventsList.Remove(eventData);
        public void Trigger()
        {
            for (int i = 0; i < commonEventsList.Count; i++)
                commonEventsList[i].EventAction.Invoke();
        }
        public void Sort() => commonEventsList.Sort();
    }

    public class EventCommon<T> : IEvent
    {
        private List<EventCommonData<T>> commonEventsList;

        public EventCommon(EventCommonData<T> eventCommonData) => commonEventsList = new List<EventCommonData<T>>() { eventCommonData };

        public void Add(EventCommonData<T> eventData) => commonEventsList.Add(eventData);
        public void Remove(EventCommonData<T> eventData) => commonEventsList.Remove(eventData);
        public void Trigger(T t)
        {
            for (int i = 0; i < commonEventsList.Count; i++)
                commonEventsList[i].EventAction.Invoke(t);
        }
        public void Sort() => commonEventsList.Sort();
    }

    public class EventInfoCommon<T, K> : IEvent
    {
        public delegate void CommonEvent(T t, K k);
        public event CommonEvent commonAction;

        public EventInfoCommon(CommonEvent commonAction)
        {
            this.commonAction += commonAction;
        }
        public void Trigger(T obj, K obj2)
        {
            commonAction?.Invoke(obj, obj2);
        }
    }

    public class EventInfoCommon<T, K, V> : IEvent
    {
        public delegate void CommonEvent(T t, K k, V v);
        public event CommonEvent commonAction;

        public EventInfoCommon(CommonEvent commonAction)
        {
            this.commonAction += commonAction;
        }
        public void Trigger(T t, K k, V v)
        {
            commonAction?.Invoke(t, k, v);
        }
    }

    public class EventInfoCommon<T, K, V, N> : IEvent
    {
        public delegate void CommonEvent(T t, K k, V v, N n);
        public event CommonEvent commonAction;

        public EventInfoCommon(CommonEvent commonAction)
        {
            this.commonAction += commonAction;
        }
        public void Trigger(T t, K k, V v, N n)
        {
            commonAction?.Invoke(t, k, v, n);
        }
    }

    public class EventInfoCommon<T, K, V, N, M> : IEvent
    {
        public delegate void CommonEvent(T t, K k, V v, N n, M m);
        public event CommonEvent commonAction;

        public EventInfoCommon(CommonEvent commonAction)
        {
            this.commonAction += commonAction;
        }
        public void Trigger(T t, K k, V v, N n, M m)
        {
            commonAction?.Invoke(t, k, v, n, m);
        }
    }
}
