﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Exercises2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        #region 练习题 请实现一个管理类，用于快捷读写自定义类对象数据
        //Test t = new Test();
        //t.i = 987;
        //t.str = "唐老狮欢迎你";

        //print(Application.persistentDataPath);
        //BinaryDataMgr.Instance.Save(t, "唐老狮哈哈哈");

        Test t = BinaryDataMgr.Instance.Load<Test>("唐老狮哈哈哈");
        #endregion
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

[System.Serializable]
public class Test
{
    public int i;
    public string str;
}
