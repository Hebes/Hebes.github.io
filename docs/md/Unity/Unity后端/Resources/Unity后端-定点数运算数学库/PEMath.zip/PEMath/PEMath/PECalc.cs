﻿/*************************************************

	日期: 2021/03/25 16:19
	功能: 常用定点数数学运算

*************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace PEMath {
    public class PECalc {
        /// <summary>
        /// 平方根
        /// </summary>
        /// <param name="value"></param>
        /// <param name="interatorCount"> 牛顿迭代法求平方根 默认迭代8次 如果8次中 2次获得一样的值则提前退出</param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public static PEInt Sqrt(PEInt value, int interatorCount = 8) {
            if(value == PEInt.zero) {
                return 0;
            }
            if(value < PEInt.zero) {
                throw new Exception();
            }

            PEInt result = value;
            PEInt history;
            int count = 0;
            do {
                history = result;
                result = (result + value / result) >> 1;
                ++count;
            } while(result != history && count < interatorCount);
            return result;
        }
        /// <summary>
        /// 反余弦函数
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static PEArgs Acos(PEInt value) {
            PEInt rate = (value * AcosTable.HalfIndexCount) + AcosTable.HalfIndexCount;
            rate = Clamp(rate, PEInt.zero, AcosTable.IndexCount);
            return new PEArgs(AcosTable.table[rate.RawInt], AcosTable.Multipler);
        }


        public static PEInt Clamp(PEInt input, PEInt min, PEInt max) {
            if(input < min) {
                return min;
            }
            if(input > max) {
                return max;
            }
            return input;
        }
    }
}
