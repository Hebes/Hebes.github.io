﻿using System;
using PEMath;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            Example1();
            //Example4();

            Console.ReadKey();
        }

        static void Example6()
        {
            PEVector3 v1 = new PEVector3(1, 0, 0);
            PEVector3 v2 = new PEVector3(1, 1, 0);
            PEArgs angle = PEVector3.Angle(v1, v2);
            Console.WriteLine($"angel view:{angle.ConvertViewAngle()}");
            Console.WriteLine($"angel float:{angle.ConvertToFloat()}");
            Console.WriteLine($"angel info:{angle}");

            PEVector3 v3 = new PEVector3(1, 0, 0);
            PEVector3 v4 = new PEVector3(1, (PEInt)1.732f, 0);
            PEArgs angle2 = PEVector3.Angle(v3, v4);
            Console.WriteLine($"angel view:{angle2.ConvertViewAngle()}");
            Console.WriteLine($"angel float:{angle2.ConvertToFloat()}");
            Console.WriteLine($"angel info:{angle2}");
        }

        static void Example5()
        {
            PEVector3 v = new PEVector3(2, 2, 2);
            Console.WriteLine("a:" + v.normalized);
            Console.WriteLine("b:" + PEVector3.Normalize(v));
            Console.WriteLine("c:" + v);
            v.Normalize();
            Console.WriteLine("c:" + v);

        }
        static void Example4()
        {
            PEVector3 v = new PEVector3(2, 2, 2);
            Console.WriteLine(v.magnitude);
            Console.WriteLine("-------");

            PEInt val = 3;
            Console.WriteLine(PECalc.Sqrt(val));
            Console.WriteLine("-------");
        }

        static void Example3()
        {
            int hp = 500;
            var val1 = hp * new PEInt(0.3f);
            Console.WriteLine("before scale:" + val1.ScaledValue);
            Console.WriteLine("before float:" + val1.RawFloat);
            Console.WriteLine("before int:" + val1.RawInt);
            Console.WriteLine("-----------");

            var val2 = hp * new PEInt(-0.3f);
            Console.WriteLine("after scale:" + val2.ScaledValue);
            Console.WriteLine("after float:" + val2.RawFloat);
            Console.WriteLine("after int:" + val2.RawInt);
        }

        static void Example2()
        {
            PEInt val1 = new PEInt(1);
            PEInt val2 = new PEInt(1.5f);
            Console.WriteLine((val1 * val2).ToString());

            PEInt val3 = new PEInt(2);
            PEInt val4 = new PEInt(0.5f);
            Console.WriteLine((val3 / val4).ToString());
        }

        static void Example1()
        {
            PEInt val1 = new PEInt(1);
            PEInt val2 = new PEInt(0.5f);

            if (val1 > val2)
                Console.WriteLine(true);
            else
                Console.WriteLine(false);

            PEInt val3 = val1 << 1;
            Console.WriteLine(val3.ToString());

            PEInt val4 = 1; //隐式转换 implicit
            PEInt val5 = (PEInt)0.5f; //显式转换 explicit

            Console.WriteLine(val4.ToString());
        }
    }
}