﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KCPExampleClient
{
    /// <summary>
    /// KCP测试 客户端
    /// </summary>
    internal class ClientStart
    {
        static void Main(string[] args)
        {
        }
    }
}
