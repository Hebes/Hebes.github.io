﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Net.Sockets.Kcp;
using System.Threading.Tasks;

namespace PENet
{
    [Serializable]
    public abstract class KCPMsg { }

    /// <summary>
    /// 基于KCP分装,实现可靠UDP传输
    /// </summary>
    public class KCPNet<T,K> 
        where T : KCPSession<K>, new() 
        where K : KCPMsg, new()
    {
        UdpClient udp;
        IPEndPoint remotePoint;

        private CancellationTokenSource cts;
        private CancellationToken ct;//关闭可以客户端的时候可以用

        public KCPNet()
        {
            cts = new CancellationTokenSource();
            ct = cts.Token;
        }

        #region 
        public T clientSession;

        public void StartAsClient(string ip, int port)
        {
            udp = new UdpClient(0);
            remotePoint = new IPEndPoint(IPAddress.Parse(ip), port);
            KCPTool.ColorLog(KCPLogColor.Green, "客户端启动 ...");

            Task.Run(ClientRecive, ct);

        }

        public void ConnectServer()
        {
            SendUDPMsg(new byte[4], remotePoint);
        }

        /// <summary>
        /// 
        /// </summary>
        public async void ClientRecive()
        {
            UdpReceiveResult result;
            while (true)
            {
                try
                {
                    if (ct.IsCancellationRequested)
                    {
                        KCPTool.ColorLog(KCPLogColor.Cyan, "ClientRecive Task is Cancelled.");
                        break;
                    }
                    result = await udp.ReceiveAsync();
                    if (Equals(remotePoint, result.RemoteEndPoint))
                    {
                        uint sid = BitConverter.ToUInt32(result.Buffer, 0);
                        if (sid == 0)
                        {
                            //sid 数据
                            if (clientSession != null && clientSession.IsConnected())
                            {
                                //已经建立连接,初始化完成了,收到了多了sid,直接丢弃
                                KCPTool.Warn("Ctient is Init Done,Sid Surplus.");
                            }
                            else
                            {
                                //未初始化，收到服务器分配的sid数据，初始化一个 客户端session
                                sid = BitConverter.ToUInt32(result.Buffer, 4);
                                KCPTool.ColorLog(KCPLogColor.Green, $"UDP Request Conv Sid:{sid}");

                                //会话处理
                                clientSession = new T();
                                clientSession.InitSession(sid, SendUDPMsg, remotePoint);
                                clientSession.OnSessionClose = OnClientSessionClose;
                            }
                        }
                        else
                        {
                            //todo 处理业务逻辑
                            if (clientSession != null && clientSession.IsConnected())
                            {
                                clientSession.ReciveData(result.Buffer);
                            }
                            else
                            {
                                //没初始化且sid≠0,数据消息提前到了，直接丢弃消息，直到初始化完成，kcp重传再开始处理。
                                KCPTool.Warn("Client is Initing...");
                            }
                        }
                    }
                    else
                    {
                        KCPTool.Warn("Client Udp Recive illegal target Data. ");
                    }
                }
                catch (Exception e)
                {
                    KCPTool.Warn($"CLient Udp Recive Data Exception:{e.ToString()}");
                }
            }
        }

        /// <summary>
        /// 连接关闭的时候需要做的事情
        /// </summary>
        /// <param name="sid"></param>
        private void OnClientSessionClose(uint sid)
        {
            cts.Cancel();
            if (udp != null)
            {
                udp.Close();
                udp = null;
            }
            KCPTool.Warn($"Client Session CLose,sid:{sid}");
        }



        #endregion

        void SendUDPMsg(byte[] bytes, IPEndPoint remotePoint)
        {
            udp?.SendAsync(bytes, bytes.Length, remotePoint);
        }
    }
}
