﻿using PENet;
using System;
using System.Net;
using System.Net.Sockets.Kcp;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace PENet
{
    public enum Sessionstate
    {
        /// <summary>
        /// 空状态
        /// </summary>
        None,
        /// <summary>
        /// 连接状态
        /// </summary>
        Connected,
        /// <summary>
        /// 分离状态
        /// </summary>
        DisConnected
    }

    /// <summary>
    /// 网络会话数据接受与发送
    /// </summary>
    public abstract class KCPSession<T> where T : KCPMsg, new()
    {
        protected uint m_sid;
        protected Action<byte[], IPEndPoint> m_udpSender;
        private IPEndPoint m_remotePoint;
        protected Sessionstate m_sessionState = Sessionstate.None;

        public Action<uint> OnSessionClose;//当连接关闭的时候的回调


        public KCPHandle m_handle;
        public Kcp m_kcp;

        private CancellationTokenSource cts;
        private CancellationToken ct;//关闭可以客户端的时候可以用

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="sid"></param>
        /// <param name="udpSender">发送器</param>
        /// <param name="remotePoint">端口号</param>
        public void InitSession(uint sid, Action<byte[], IPEndPoint> udpSender, IPEndPoint remotePoint)
        {
            m_sid = sid;
            m_udpSender = udpSender;//发送器
            m_remotePoint = remotePoint;//端口号
            m_sessionState = Sessionstate.Connected;//连接状态

            m_handle = new KCPHandle();
            m_kcp = new Kcp(sid, m_handle);

            //KCP配置
            m_kcp.NoDelay(1, 10, 2, 1);
            m_kcp.WndSize(64, 64);
            m_kcp.SetMtu(512);

            m_handle.Out = (Memory<byte> buffer) =>
            {
                byte[] bytes = buffer.ToArray();
                m_udpSender(bytes, m_remotePoint);
            };

            //这边就是拿到了有序的数据进行处理
            m_handle.Recv = (byte[] buffer) =>
            {
                buffer = KCPTool.DeCompress(buffer);
                T msg = KCPTool.DeSerialize<T>(buffer);
                if (msg != null)
                {
                    OnReciveMsg(msg);
                }
            };

            OnConnected();


            cts = new CancellationTokenSource();
            ct = cts.Token;

            Task.Run(Update, ct);
        }
        /// <summary>
        /// 发送消息前先放入这边,接受数据
        /// </summary>
        /// <param name="buffer"></param>
        public void ReciveData(byte[] buffer)
        {
            m_kcp.Input(buffer.AsSpan());
        }


        public void SendMsg(T msg)
        {
            if (IsConnected())
            {
                byte[] bytes = KCPTool.Serialize(msg);
                if (bytes != null)
                    SendMsg(bytes);
            }
            else
                KCPTool.Warn("Session Disconnected.Can not send msg.");
        }
        public void SendMsg(byte[] msg_bytes)
        {
            if (IsConnected())
            {
                msg_bytes = KCPTool.Compress(msg_bytes);
                m_kcp.Send(msg_bytes.AsSpan());
            }
            else
                KCPTool.Warn(" Session Disconnected.Can not send msg. ");
        }
        public void Closesession()
        {
            cts.Cancel();

            OnDisConnected();

            OnSessionClose?.Invoke(m_sid);
            OnSessionClose = null;

            m_sessionState = Sessionstate.DisConnected;
            m_remotePoint = null;
            m_udpSender = null;
            m_sid = 0;
            m_handle = null;
            m_kcp = null;
            cts = null;
        }



        async void Update()
        {
            try
            {
                while (true)
                {
                    DateTime now = DateTime.UtcNow;
                    OnUpdate(now);
                    if (ct.IsCancellationRequested)
                    {
                        KCPTool.ColorLog(KCPLogColor.Cyan, "SessionUpdate Task is Cancelled.");
                        break;
                    }
                    else
                    {
                        m_kcp.Update(now);

                        int Len;
                        while ((Len = m_kcp.PeekSize()) > 0)
                        {
                            var buffer = new byte[Len];
                            if (m_kcp.Recv(buffer) >= 0)
                            {
                                m_handle.Recv(buffer);
                            }
                        }
                        await Task.Delay(10);
                    }
                }
            }
            catch (Exception e)
            {
                KCPTool.Warn($" Session Update Exception:{e.ToString()}");
            }
        }

        protected abstract void OnConnected();
        protected abstract void OnUpdate(DateTime now);
        protected abstract void OnReciveMsg(T msg);
        protected abstract void OnDisConnected();

        public bool IsConnected()
        {
            return m_sessionState == Sessionstate.Connected;
        }
        public override bool Equals(object obj)
        {
            if (obj is KCPSession<T>)
            {
                KCPSession<T> us = obj as KCPSession<T>;
                return m_sid == us.m_sid;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return m_sid.GetHashCode();
        }
        public uint GetSessionID()
        {
            return m_sid;
        }
    }
}






