﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Sockets.Kcp;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text;
using System.IO.Compression;
using System.Threading;
using System.Runtime.CompilerServices;

namespace PENet
{
    public enum KCPLogColor
    {
        None,
        Red,
        Green,
        Blue,
        Cyan,
        Magentna,
        Yellow,
    }

    /// <summary>
    /// KCPNet网络库工具类
    /// </summary>
    public class KCPTool
    {
        public static Action<string> LogFunc;//日志
        public static Action<KCPLogColor, string> CoLorLogFunc;
        public static Action<string> WarnFunc;//警告
        public static Action<string> ErrorFunc;//错误


        //****************************日志****************************
        /// <summary>
        /// 日志
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public static void Log(string msg, params object[] args)
        {
            msg = string.Format(msg, args);
            LogFunc?.Invoke(msg);
            if (LogFunc == null)
                ConsoLeLog(msg, KCPLogColor.None);
        }
        /// <summary>
        /// 颜色日志
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public static void ColorLog(KCPLogColor color, string msg, params object[] args)
        {
            msg = string.Format(msg, args);
            CoLorLogFunc?.Invoke(color, msg);
            if (CoLorLogFunc == null)
                ConsoLeLog(msg, color);
        }
        /// <summary>
        /// 警告
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public static void Warn(string msg, params object[] args)
        {
            msg = string.Format(msg, args);
            WarnFunc?.Invoke(msg);
            if (WarnFunc == null)
                ConsoLeLog(msg, KCPLogColor.Red);
        }
        /// <summary>
        /// 错误
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="args"></param>
        public static void Error(string msg, params object[] args)
        {
            msg = string.Format(msg, args);
            ErrorFunc?.Invoke(msg);
            if (ErrorFunc == null)
                ConsoLeLog(msg, KCPLogColor.None);
        }
        private static void ConsoLeLog(string msg, KCPLogColor color)
        {
            int threadID = Thread.CurrentThread.ManagedThreadId;
            msg = string.Format("Thread:{0} {1}", threadID, msg);
            switch (color)
            {
                case KCPLogColor.Red: ConsoLeLogColor(ConsoleColor.DarkRed, msg, ConsoleColor.Gray); break;
                case KCPLogColor.Green: ConsoLeLogColor(ConsoleColor.Green, msg, ConsoleColor.Gray); break;
                case KCPLogColor.Blue: ConsoLeLogColor(ConsoleColor.Blue, msg, ConsoleColor.Gray); break;
                case KCPLogColor.Cyan: ConsoLeLogColor(ConsoleColor.Cyan, msg, ConsoleColor.Gray); break;
                case KCPLogColor.Magentna: ConsoLeLogColor(ConsoleColor.Magenta, msg, ConsoleColor.Gray); break;
                case KCPLogColor.Yellow: ConsoLeLogColor(ConsoleColor.Yellow, msg, ConsoleColor.Gray); break;
                case KCPLogColor.None:
                default:
                    break;
            }
        }
        private static void ConsoLeLogColor(ConsoleColor consoleColor1, string msg, ConsoleColor consoleColor2)
        {
            Console.ForegroundColor = consoleColor1;
            Console.WriteLine(msg);
            Console.ForegroundColor = consoleColor2;
        }


        //****************************序列化与反序列化****************************
        /// <summary>
        /// 序列化,把类转成字节数组
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static byte[] Serialize<T>(T msg) where T : KCPMsg
        {
            using (MemoryStream ms = new MemoryStream())
            {
                try
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(ms, msg);
                    ms.Seek(0, SeekOrigin.Begin);
                    return ms.ToArray();
                }
                catch (SerializationException e)
                {
                    Error("Failed to serialize .Reason:{0}", e.Message);
                    throw;
                }
            }
        }

        /// <summary>
        /// 反序列化,把字节数组转成类
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static T DeSerialize<T>(byte[] bytes) where T : KCPMsg
        {
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                try
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    T msg = (T)bf.Deserialize(ms);
                    return msg;
                }
                catch (SerializationException e)
                {
                    Error($"Failed to DeSerialize.Reason:{e.Message},bytesLength:{bytes.Length}" );
                    throw;
                }
            }
        }


        //****************************压缩与解压缩****************************
        /// <summary>
        /// 压缩
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static byte[] Compress(byte[] input)
        {
            using (MemoryStream outMS = new MemoryStream())
            {
                using (GZipStream gzs = new GZipStream(outMS, CompressionMode.Compress, true))
                {
                    gzs.Write(input, 0, input.Length);
                    gzs.Close();
                    return outMS.ToArray();
                }
            }
        }

        /// <summary>
        /// 解压缩
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static byte[] DeCompress(byte[] input)
        {
            using (MemoryStream inputMS = new MemoryStream(input))
            {
                using (MemoryStream outMs = new MemoryStream())
                {
                    using (GZipStream gzs = new GZipStream(inputMS, CompressionMode.Decompress))
                    {
                        byte[] bytes = new byte[1024];
                        int Len = 0;
                        while ((Len = gzs.Read(bytes, 0, bytes.Length)) > 0)
                            outMs.Write(bytes, 0,Len);
                        gzs.Close();
                        return outMs.ToArray();
                    }
                }
            }
        }

        //****************************获取从1970年1月1号的毫秒数****************************
        static readonly DateTime utcStart =new DateTime(1970,1,1);
        public static ulong GetutcStartMilliseconds()
        {
            TimeSpan ts = DateTime.UtcNow - utcStart;
            return (ulong)ts.TotalMilliseconds;
        }
    }
}



