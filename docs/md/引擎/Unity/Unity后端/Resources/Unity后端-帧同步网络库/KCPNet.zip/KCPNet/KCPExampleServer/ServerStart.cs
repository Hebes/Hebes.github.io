﻿/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    服务端控制台

-----------------------*/

using KCPExampLeProtocol;
using PENet;
using System;

namespace KCPExampleServer
{
    public class ServerStart
    {
        static void Main(string[] args)
        {
            string ip = "192.168.1.178";
            KCPNet<ServerSession, NetMsg> server = new KCPNet<ServerSession, NetMsg>();
            server.StartAsServer(ip, 17666);
            while (true)
            {
                string ipt = Console.ReadLine();
                if (ipt == "quit")
                {
                    server.CloseServer();
                    break;
                }
                else
                {
                    server.BroadCastMsg(new NetMsg { info = ipt });
                    Console.ReadKey();
                }
            }
        }
    }
}