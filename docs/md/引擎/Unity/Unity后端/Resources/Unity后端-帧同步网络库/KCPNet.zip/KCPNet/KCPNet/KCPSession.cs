﻿using PENet;
using System;
using System.Net;
using System.Net.Sockets.Kcp;
using System.Threading;
using System.Threading.Tasks;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    网络会话数据接受与发送

-----------------------*/

namespace PENet
{
    public enum SessionState
    {
        None,           //空状态
        Connected,      //连接状态
        DisConnected,   //分离状态
    }

    public abstract class KCPSession<T> where T : KCPMsg, new()
    {
        protected uint m_sid;
        Action<byte[], IPEndPoint> m_udpSender;
        private IPEndPoint m_remotePoint;
        protected SessionState m_sessionState = SessionState.None;
        public Action<uint> OnSessionClose;

        public KCPHandle m_handle;
        public Kcp m_kcp;
        private CancellationTokenSource cts;
        private CancellationToken ct;

        public void InitSession(uint sid, Action<byte[], IPEndPoint> udpSender, IPEndPoint remotePoint)
        {
            m_sid = sid;                            //标志id
            m_udpSender = udpSender;                //发送数据 发送目标ip
            m_remotePoint = remotePoint;            //远程ip
            m_sessionState = SessionState.Connected;//链接

            m_handle = new KCPHandle();
            m_kcp = new Kcp(sid, m_handle); //初始化kcp
            m_kcp.NoDelay(1, 10, 2, 1);
            m_kcp.WndSize(64, 64);
            m_kcp.SetMtu(512);

            m_handle.Out = (Memory<byte> buffer) => {
                byte[] bytes = buffer.ToArray();
                m_udpSender(bytes, m_remotePoint);
            };

            m_handle.Recv = (byte[] buffer) => {
                buffer = KCPTool.DeCompress(buffer);
                T msg = KCPTool.DeSerialize<T>(buffer);
                if (msg != null)
                    OnReciveMsg(msg);
            };

            OnConnected();

            cts = new CancellationTokenSource();
            ct = cts.Token;
            Task.Run(Update, ct);
        }//初始化

        public void ReciveData(byte[] buffer)
        {
            m_kcp.Input(buffer.AsSpan());
        }//接受数据

        public void SendMsg(T msg)
        {
            if (IsConnected())
            {
                byte[] bytes = KCPTool.Serialize(msg);
                if (bytes != null)
                {
                    SendMsg(bytes);
                }
            }
            else
            {
                KCPTool.Warn("Session Disconnected.Can not send msg.");
            }
        }//发送信息
        public void SendMsg(byte[] msg_bytes)
        {
            if (IsConnected())
            {
                msg_bytes = KCPTool.Compress(msg_bytes);
                m_kcp.Send(msg_bytes.AsSpan());
            }
            else
            {
                KCPTool.Warn("Session Disconnected.Can not send msg.");
            }
        } //重载 为了节省序列化性能 类似广播时调用
        public void CloseSession()
        {
            cts.Cancel();
            OnDisConnected();

            OnSessionClose?.Invoke(m_sid);
            OnSessionClose = null;

            m_sessionState = SessionState.DisConnected;
            m_remotePoint = null;
            m_udpSender = null;
            m_sid = 0;

            m_handle = null;
            m_kcp = null;
            cts = null;
        }//关闭连接

        async void Update()
        {
            try
            {
                while (true)
                {
                    DateTime now = DateTime.UtcNow;
                    OnUpdate(now);
                    if (ct.IsCancellationRequested)
                    {
                        KCPTool.ColorLog(KCPLogColor.Cyan, "会话更新任务取消,Session Update Task is Cancelled.");
                        break;
                    }
                    else
                    {
                        m_kcp.Update(now);
                        int len;
                        while ((len = m_kcp.PeekSize()) > 0)
                        {
                            var buffer = new byte[len];
                            if (m_kcp.Recv(buffer) >= 0)
                                m_handle.Recive(buffer);
                        }
                        await Task.Delay(10);
                    }
                }
            }
            catch (Exception e)
            {
                KCPTool.Warn("Session异常,Session Update Exception:{0}", e.ToString());
            }
        }

        protected abstract void OnUpdate(DateTime now);//更新.里面可以写实现心跳机制等
        protected abstract void OnConnected();//连接
        protected abstract void OnReciveMsg(T msg);//接收Msg
        protected abstract void OnDisConnected();//连接中断的时候


        public override bool Equals(object obj)
        {
            if (obj is KCPSession<T>)
            {
                KCPSession<T> us = obj as KCPSession<T>;
                return m_sid == us.m_sid;
            }
            return false;
        }//对比
        public override int GetHashCode()
        {
            return m_sid.GetHashCode();
        }//获取哈希码
        public uint GetSessionID()
        {
            return m_sid;
        }//获取SessionID
        public bool IsConnected()
        {
            return m_sessionState == SessionState.Connected;
        }//是否连接
    }
}
