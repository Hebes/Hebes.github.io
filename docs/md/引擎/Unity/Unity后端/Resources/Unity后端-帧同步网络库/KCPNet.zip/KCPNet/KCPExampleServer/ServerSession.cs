﻿using KCPExampLeProtocol;
using PENet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    服务端Session连接

-----------------------*/

namespace KCPExampleServer
{
    public class ServerSession : KCPSession<NetMsg>
    {
        protected override void OnConnected()
        {
            KCPTool.ColorLog(KCPLogColor.Green, "CLient OnLine,Sid:{0}", m_sid);
        }

        protected override void OnDisConnected()
        {
            KCPTool.Warn("CLient Offline,Sid: {0}", m_sid);
        }

        protected override void OnReciveMsg(NetMsg msg)
        {
            KCPTool.ColorLog(KCPLogColor.Magentna, "sid: {0} , RcvClient, CMD:{1} {2}", m_sid, msg.cmd.ToString(), msg.info);

            if (msg.cmd == CMD.NetPing)
            {
                if (msg.netPing.isover)
                    CloseSession();
                else
                {
                    //收到ping请求，则重置检查计数，并回复ping消息到客户端
                    checkCounter = 0;

                    NetMsg pingMsg = new NetMsg
                    {
                        cmd = CMD.NetPing,
                        netPing = new NetPing
                        {
                            isover = false
                        },
                    };
                    SendMsg(pingMsg);
                }
            }
        }


        private int checkCounter;
        DateTime checkTime = DateTime.UtcNow.AddSeconds(5);

        protected override void OnUpdate(DateTime now)
        {
            if (now > checkTime)
            {
                checkTime = now.AddSeconds(5);
                checkCounter++;
                if (checkCounter > 3)
                {
                    NetMsg pingMsg = new NetMsg
                    {
                        cmd = CMD.NetPing,
                        netPing = new NetPing { isover = true }
                    };
                    OnReciveMsg(pingMsg);
                }
            }
        }
    }
}
