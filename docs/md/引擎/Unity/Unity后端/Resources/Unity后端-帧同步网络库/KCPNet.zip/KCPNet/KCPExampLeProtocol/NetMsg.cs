﻿using PENet;
using System;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    网络通信数据协议

-----------------------*/

namespace KCPExampLeProtocol
{
    [Serializable]
    public class NetMsg : KCPMsg
    {
        public CMD cmd;
        public NetPing netPing;
        public string info;
    }

    [Serializable]
    public class NetPing
    {
        //是否结束连接
        public bool isover;
    }

    public enum CMD
    {
        None,
        ReqLogin,
        NetPing
    }

}
