﻿using KCPExampLeProtocol;
using PENet;
using System;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    客户端Session连接

-----------------------*/

namespace KCPExampleClient
{
    public class ClientSession : KCPSession<NetMsg>
    {
        protected override void OnConnected()
        {
        }

        protected override void OnDisConnected()
        {
        }

        protected override void OnReciveMsg(NetMsg msg)
        {
            KCPTool.ColorLog(KCPLogColor.Magentna, $"Sid: {m_sid}, RcVServer:{msg.info}");

        }

        protected override void OnUpdate(DateTime now)
        {
        }
    }
}
