﻿using KCPExampLeProtocol;
using Microsoft.SqlServer.Server;
using PENet;
using System;
using System.Threading.Tasks;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    KCP测试 客户端

-----------------------*/

namespace KCPExampleClient
{
    public class ClientStart
    {

        public static KCPNet<ClientSession, NetMsg> client;
        public static Task<bool> checkTask;

        public static void Main(string[] args)
        {
            string ip = "192.168.1.178";
            client = new KCPNet<ClientSession, NetMsg>();
            client.StartAsClient(ip, 17666);
            checkTask = client.ConnectServer(200);
            Task.Run(ConnectCheck);//心跳检测函数

            while (true)
            {
                string ipt = Console.ReadLine();
                if (ipt == "quit")
                {
                    client.CloseClient();
                    break;
                }
                else
                {
                    client.clientSession.SendMsg(new NetMsg
                    {
                        info = ipt
                    });
                }
            }
            Console.ReadKey();
        }

        private static int counter = 0;
        static async void ConnectCheck()
        {
            while (true)
            {
                await Task.Delay(3000);
                if (checkTask != null && checkTask.IsCompleted)
                {
                    if (checkTask.Result)
                    {
                        KCPTool.ColorLog(KCPLogColor.Green, "ConnectServer Success. ");
                        checkTask = null;
                        await Task.Run(SendPingMsg);
                    }
                    else
                    {
                        ++counter;
                        if (counter > 4)
                        {
                            KCPTool.Error(string.Format("Connect Failed {0} Times, Check Your Network Connection.", counter));
                            checkTask = null;
                            break;
                        }
                        else
                        {
                            KCPTool.Warn(string.Format("Connect Faild {0} Times . Retry ... "), counter);
                            checkTask = client.ConnectServer(200, 5000);
                        }
                    }
                }
            }
        }

        static async void SendPingMsg()
        {
            while (true)
            {
                await Task.Delay(5000);
                if (client != null & client.clientSession != null)
                {
                    client.clientSession.SendMsg(new NetMsg
                    {
                        cmd = CMD.NetPing,
                        netPing = new NetPing
                        {
                            isover = false
                        }
                    });
                    KCPTool.ColorLog(KCPLogColor.Green, "CLient Send Ping Message.");
                }
                else
                {
                    KCPTool.ColorLog(KCPLogColor.Green, "Ping Task CanceL");
                    break;
                }
            }
        }

    }
}
