﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

/*--------脚本描述-----------
				
电子邮箱：
	1607388033@qq.com
作者:
	暗沉
描述:
    基于KCP封装，实现可靠UDP

-----------------------*/

namespace PENet
{
    [Serializable]
    public abstract class KCPMsg { }

    public class KCPNet<T, K>
        where T : KCPSession<K>, new()
        where K : KCPMsg, new()
    {
        UdpClient udp;
        IPEndPoint remotePoint;

        private CancellationTokenSource cts;    //多线程
        private CancellationToken ct;

        public KCPNet()
        {
            cts = new CancellationTokenSource();
            ct = cts.Token;
        }

        #region 服务端
        private Dictionary<uint, T> sessionDic = null;
        public void StartAsServer(string ip, int port)
        {
            sessionDic = new Dictionary<uint, T>();

            udp = new UdpClient(new IPEndPoint(IPAddress.Parse(ip), port));
            //在windows 如果关闭 链接的客户端 就会疯狂打印error信息 解决
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                udp.Client.IOControl((IOControlCode)(-1744830452), new byte[] { 0, 0, 0, 0 }, null);
            remotePoint = new IPEndPoint(IPAddress.Parse(ip), port);
            KCPTool.ColorLog(KCPLogColor.Green, " 服务端启动,Server Start...");
            Task.Run(ServerRecive, ct);
        }
        async void ServerRecive()
        {
            UdpReceiveResult result;
            while (true)
            {
                try
                {
                    if (ct.IsCancellationRequested)
                    {
                        KCPTool.ColorLog(KCPLogColor.Cyan, "SeverRecive Task is Cancelled.");
                        break;
                    }
                    result = await udp.ReceiveAsync();
                    uint sid = BitConverter.ToUInt32(result.Buffer, 0);
                    if (sid == 0)
                    {
                        //生成全局唯一的sid
                        sid = GenerateUniqueSessionID();
                        byte[] sid_bytes = BitConverter.GetBytes(sid);
                        byte[] conv_bytes = new byte[8];
                        Array.Copy(sid_bytes, 0, conv_bytes, 4, 4);
                        SendUDPMsg(conv_bytes, result.RemoteEndPoint);//发回给客户端 sid
                    }
                    else
                    {
                        if (!sessionDic.TryGetValue(sid, out T session))
                        {
                            session = new T();
                            session.InitSession(sid, SendUDPMsg, result.RemoteEndPoint);
                            session.OnSessionClose = OnServerSessionClose;
                            lock (sessionDic)
                            {
                                sessionDic.Add(sid, session);
                            }
                        }
                        else
                        {
                            session = sessionDic[sid];
                        }
                        session.ReciveData(result.Buffer);
                    }
                }
                catch (Exception e)
                {
                    KCPTool.Warn("Server Udp Recive Data Exception:{0}", e.ToString());
                }
            }
        }//服务端接收
        void OnServerSessionClose(uint sid)
        {
            if (sessionDic.ContainsKey(sid))
            {
                lock (sessionDic)
                {
                    sessionDic.Remove(sid);
                    KCPTool.Warn("Session:{0} remove from sessionDic.", sid);
                }
            }
            else
            {
                KCPTool.Error("Session:{0} cannot find in sessionDic", sid);
            }
        }
        public void CloseServer()
        {
            foreach (var item in sessionDic)
                item.Value.CloseSession();
            sessionDic = null;

            if (udp != null)
            {
                udp.Close();
                udp = null;
                cts.Cancel();
            }
        }
        #endregion

        #region 客户端
        public T clientSession;
        public void StartAsClient(string ip, int port)
        {
            udp = new UdpClient(0);
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                udp.Client.IOControl((IOControlCode)(-1744830452), new byte[] { 0, 0, 0, 0 }, null);
            remotePoint = new IPEndPoint(IPAddress.Parse(ip), port);
            KCPTool.ColorLog(KCPLogColor.Green, "Client Start...");

            Task.Run(ClientRecive, ct);//多线程
        }
        public Task<bool> ConnectServer(int interval, int maxintervalSum = 5000)
        {
            SendUDPMsg(new byte[4], remotePoint);//发送4个字节 全部为0的数据 如果全部为0 则服务器默认 认为这是个全新的链接
            int checkTimes = 0;//实现心跳机制,保证与服务端连接
            Task<bool> task = Task.Run(async () =>
            {
                while (true)
                {
                    await Task.Delay(interval);
                    checkTimes += interval;
                    if (clientSession != null && clientSession.IsConnected())
                        return true;
                    else
                    {
                        if (checkTimes > maxintervalSum)
                            return false;
                    }
                }
            });
            return task;
        }//链接服务器
        async void ClientRecive()
        {
            UdpReceiveResult result;
            while (true)
            {
                try
                {
                    if (ct.IsCancellationRequested)
                    {
                        //终止掉死循环
                        KCPTool.ColorLog(KCPLogColor.Cyan, "客户端服务任务取消,ClientRecive Task is Cancelled.");
                        break;
                    }

                    result = await udp.ReceiveAsync();

                    //验证ip 是否正确
                    if (Equals(remotePoint, result.RemoteEndPoint))
                    {
                        uint sid = BitConverter.ToUInt32(result.Buffer, 0);
                        if (sid == 0)
                        {
                            //sid 数据
                            if (clientSession != null && clientSession.IsConnected())
                                KCPTool.Warn("初始化完成了Sid过剩,Client is Init Done,Sid Surplus.");//已经建立连接，初始化完成了，收到了多的sid,直接丢弃。
                            else
                            {
                                //未初始化，收到服务器分配的sid数据，初始化一个客户端session
                                sid = BitConverter.ToUInt32(result.Buffer, 4);
                                KCPTool.ColorLog(KCPLogColor.Green, $"UDP请求参数,UDP Request Conv Sid:{sid}");

                                //会话处理
                                clientSession = new T();
                                clientSession.InitSession(sid, SendUDPMsg, remotePoint);//初始化Session
                                clientSession.OnSessionClose = OnClientSessionClose;
                            }
                        }
                        else
                        {
                            //处理业务逻辑
                            if (clientSession != null && clientSession.IsConnected())
                                clientSession.ReciveData(result.Buffer);
                            else
                                //没初始化且sid!=0，数据消息提前到了，直接丢弃消息，直到初始化完成，kcp重传再开始处理。
                                KCPTool.Warn("客户端正在初始化,Client is Initing...");
                        }
                    }
                    else
                        KCPTool.Warn("Client Udp Recive illegal target Data.");
                }
                catch (Exception e)
                {
                    KCPTool.Warn("Client Udp Recive Data Exception:{0}", e.ToString());
                }
            }
        }
        void OnClientSessionClose(uint sid)
        {
            cts.Cancel();
            if (udp != null) { udp.Close(); udp = null; }
            KCPTool.Warn($"Client Session Close,sid:{sid}");
        }//客户端Session关闭
        public void CloseClient()
        {
            clientSession?.CloseSession();
        }
        #endregion

        private void SendUDPMsg(byte[] bytes, IPEndPoint remotePoint)
        {
            udp?.SendAsync(bytes, bytes.Length, remotePoint);
        }

        public void BroadCastMsg(K msg)
        {
            byte[] bytes = KCPTool.Serialize<K>(msg);
            foreach (var item in sessionDic)
            {
                item.Value.SendMsg(bytes);
            }
        }
        private uint sid = 0;
        public uint GenerateUniqueSessionID()
        {
            lock (sessionDic)
            {
                while (true)
                {
                    ++sid;
                    if (sid == uint.MaxValue)
                    {
                        sid = 1;
                    }
                    if (!sessionDic.ContainsKey(sid))
                    {
                        break;
                    }
                }
            }
            return sid;
        }//生成全局唯一的 session ID
    }

}
