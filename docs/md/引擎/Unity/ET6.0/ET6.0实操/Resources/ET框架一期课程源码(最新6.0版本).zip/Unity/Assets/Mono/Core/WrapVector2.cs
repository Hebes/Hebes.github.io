﻿using UnityEngine;

namespace ET
{
    // 消除ILRuntime的GC用的
    public class WrapVector2
    {
        public Vector2 Value;
    }
}