﻿using UnityEngine;

namespace ET
{
    // 消除ILRuntime的GC用的
    public class WrapQuaternion
    {
        public Quaternion Value;
    }
}