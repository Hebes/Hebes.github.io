﻿using System.Collections.Generic;
using UnityEngine;

namespace ET
{
    public static class PathFindHelper
    {
        public static void PathFind(int mapId, Vector3 from, Vector3 to, List<Vector3> result)
        {
            
        }
    }
}