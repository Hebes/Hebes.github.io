﻿namespace ET
{
    [ComponentOf(typeof(Session))]
    [ChildType(typeof(RoleInfo))]
    public class RoleInfosZone : Entity,IAwake
    {
        
    }
}