namespace ET
{
	public static partial class MongoOpcode
	{
		 public const ushort ObjectQueryResponse = 30002;
		 public const ushort M2M_UnitTransferRequest = 30003;
		 public const ushort UnitCache2Other_GetUnit = 30004;
		 public const ushort Map2Rank_AddOrUpdateRankInfo = 30005;
	}
}
