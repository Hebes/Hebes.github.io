namespace ET
{
    public interface IDBCollection
    {
    }
}