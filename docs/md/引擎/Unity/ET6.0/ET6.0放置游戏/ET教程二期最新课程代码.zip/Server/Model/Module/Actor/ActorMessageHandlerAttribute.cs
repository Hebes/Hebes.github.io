﻿namespace ET
{
    public class ActorMessageHandlerAttribute: BaseAttribute
    {
    }
}