﻿namespace ET
{
    [ComponentOf(typeof(Session))]
    public class SessionLockingComponent : Entity,IAwake
    {
        
    }
}