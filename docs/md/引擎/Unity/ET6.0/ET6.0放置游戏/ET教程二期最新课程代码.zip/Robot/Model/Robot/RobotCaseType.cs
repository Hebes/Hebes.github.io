namespace ET
{
    public static class RobotCaseType
    {
        public const int FirstCase = 1;

        public const int MaxCaseType = 10000;
    }
}