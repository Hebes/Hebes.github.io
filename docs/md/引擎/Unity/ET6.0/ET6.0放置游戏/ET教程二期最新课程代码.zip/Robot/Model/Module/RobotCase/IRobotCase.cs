namespace ET
{
    public interface IRobotCase
    {
        ETTask Run(RobotCase robotCase);
    }
}