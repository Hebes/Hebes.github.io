﻿using UnityEngine;

namespace ET
{
    // 消除ILRuntime的GC用的
    public class WrapVector3
    {
        public Vector3 Value;
    }
}