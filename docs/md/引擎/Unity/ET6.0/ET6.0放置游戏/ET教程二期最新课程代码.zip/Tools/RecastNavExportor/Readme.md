## 使用说明

双击打开RecastDemo.exe文件

（如果出现报错说明是电脑本身缺少VisualC++库，可以下载一个Visual Studio然后安装如图所示模块即可）
![QQ截图20220113193347](https://user-images.githubusercontent.com/35335061/149324942-01a7cf02-81b8-4620-9f73-77427819316e.png)


随后选中模型，并进行参数调控与Nav数据烘焙即可
![QQ截图20220113193440](https://user-images.githubusercontent.com/35335061/149324982-1c1f26a9-e53f-4b9c-914a-4bffe3ba129b.png)
![QQ截图20220113193509](https://user-images.githubusercontent.com/35335061/149325003-6d6fc062-7123-443a-ae07-a852fe50d3f9.png)


导出的nav数据文件位于
![QQ截图20220113193546](https://user-images.githubusercontent.com/35335061/149324992-465257b9-0274-49ce-bb12-9fac113ed1a2.png)


可根据需要放置到指定目录
