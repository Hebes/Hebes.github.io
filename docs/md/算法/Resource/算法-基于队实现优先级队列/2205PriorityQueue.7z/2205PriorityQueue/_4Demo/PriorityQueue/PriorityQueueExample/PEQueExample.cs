﻿/*************************************************
	作者: Plane
	邮箱: 1785275942@qq.com	
	功能: 控制台测试程序

    //=================*=================\\
           教学官网：www.qiqiker.com
           官方微信服务号: qiqikertuts
           Plane老师微信: PlaneZhong
               ~~获取更多教学资讯~~
    \\=================*=================//
*************************************************/

using System;
using System.Collections.Generic;

namespace PriorityQueueExample {
    public class Item : IComparable<Item> {
        public string itemName;
        public float priority;
        public int CompareTo(Item other) {
            if(priority < other.priority) {
                return -1;
            }
            else if(priority > other.priority) {
                return 1;
            }
            else {
                return 0;
            }
        }

        public void PrintInfo() {
            Console.WriteLine($"itemName:{itemName} priority:{priority}");
        }
    }

    class PEQueExample {
        static void Main(string[] args) {
            int count = 1000000;
            while(count > 0) {
                count--;
                LoopTest();
            }

            Console.WriteLine("---------Test Succ!!!--------");

            Console.ReadKey();
        }

        static void LoopTest() {
            //random add data
            Random rd = new Random();
            int genCount = rd.Next(100, 9999);
            List<Item> itemLst = new List<Item>(genCount);
            for(int i = 0; i < genCount; i++) {
                itemLst.Add(new Item {
                    itemName = $"item_{i}",
                    priority = rd.Next(0, 10000)
                });
            }

            //enqueue
            PEQue<Item> pque = new PEQue<Item>();
            for(int i = 0; i < itemLst.Count; i++) {
                pque.Enqueue(itemLst[i]);
            }

            //random rmv item
            int rmvCount = rd.Next(1, 9999);
            for(int i = 0; i < rmvCount; i++) {
                int index = rd.Next(0, pque.Count);
                int pqIndex = pque.IndexOf(itemLst[index]);
                if(pqIndex >= 0) {
                    pque.RemoveAt(pqIndex);
                }
            }

            //dequeue
            List<Item> outLst = new List<Item>();
            while(pque.Count > 0) {
                Item item = pque.Dequeue();
                outLst.Add(item);
                item.PrintInfo();
            }

            //order check
            for(int i = 0; i < outLst.Count; i++) {
                if(i < outLst.Count - 1) {
                    if(outLst[i].priority > outLst[i + 1].priority) {
                        Exception e = new Exception("优先级异常。");
                        throw e;
                    }
                }
            }
        }
    }
}
