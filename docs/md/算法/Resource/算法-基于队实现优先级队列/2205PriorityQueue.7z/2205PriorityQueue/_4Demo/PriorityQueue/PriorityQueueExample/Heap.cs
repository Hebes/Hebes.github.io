﻿/*************************************************
	作者: Plane
	邮箱: 1785275942@qq.com	
	功能: 小顶堆

    //=================*=================\\
           教学官网：www.qiqiker.com
           官方微信服务号: qiqikertuts
           Plane老师微信: PlaneZhong
               ~~获取更多教学资讯~~
    \\=================*=================//
*************************************************/

using System.Collections.Generic;

namespace PEUtils {
    public class Heap {
        public List<int> lst = null;

        public Heap(int capacity = 4) {
            lst = new List<int>(capacity);
        }

        /// <summary>
        /// 用整数示例，添加一个节点到当前堆中
        /// </summary>
        public void AddNode(int value) {
            lst.Add(value);
            int childIndex = lst.Count - 1;
            int parentIndex = (childIndex - 1) / 2;
            while(childIndex > 0 && lst[childIndex] < lst[parentIndex]) {
                Swap(childIndex, parentIndex);
                childIndex = parentIndex;
                parentIndex = (childIndex - 1) / 2;
            }
        }

        /// <summary>
        /// 移除堆顶元素
        /// </summary>
        public int RmvNode() {
            if(lst.Count == 0) {
                return int.MinValue;
            }
            int value = lst[0];
            int endIndex = lst.Count - 1;
            lst[0] = lst[endIndex];
            lst.RemoveAt(endIndex);
            --endIndex;
            int topIndex = 0;
            while(true) {
                int minIndex = topIndex;

                //left
                int childIndex = topIndex * 2 + 1;
                if(childIndex <= endIndex && lst[childIndex] < lst[topIndex]) {
                    minIndex = childIndex;
                }

                childIndex = topIndex * 2 + 2;
                if(childIndex <= endIndex && lst[childIndex] < lst[minIndex]) {
                    minIndex = childIndex;
                }

                if(topIndex == minIndex) {
                    break;
                }
                Swap(topIndex, minIndex);
                topIndex = minIndex;
            }

            return value;
        }

        void Swap(int a, int b) {
            int temp = lst[a];
            lst[a] = lst[b];
            lst[b] = temp;
        }
    }
}
