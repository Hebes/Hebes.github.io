﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace PETimer
{
    /// <summary>
    /// 使用外部帧循环调用驱动，并在帧循环中回调
    /// </summary>
    public class FrameTimer : PETimer
    {
        private ulong currentFrame;
        private const string tidlock = "FrameTimer_tidlock";
        private readonly Dictionary<int, FrameTask> taskDic;

        private List<int> tidLst;
        public FrameTimer(ulong frameID = 0)
        {
            currentFrame = frameID;
            taskDic = new Dictionary<int, FrameTask>();
            tidLst = new List<int>();
        }

        /// <summary>
        /// 添加任务
        /// </summary>
        /// <param name="delay">多少帧数</param>
        /// <param name="taskCB"></param>
        /// <param name="canceLCB"></param>
        /// <param name="count">执行多少次</param>
        /// <returns></returns>
        public override int AddTask(uint delay, Action<int> taskCB, Action<int> canceLCB, int count = 1)
        {
            int tid = GenerateTid();
            ulong destFrame = currentFrame + delay;
            FrameTask task = new FrameTask(tid, delay, count, destFrame, taskCB, canceLCB);
            if (taskDic.ContainsKey(tid))
            {
                WarnFunc?.Invoke($"key:{tid} already exist.");
                return -1;
            }
            else
            {
                taskDic.Add(tid, task);
                return tid;
            }
        }

        public override bool DeleteTask(int tid)
        {
            if (taskDic.TryGetValue(tid, out FrameTask task))
            {
                if (taskDic.Remove(tid))
                {
                    task.cancelCB?.Invoke(tid);
                    return true;
                }
                else
                {
                    ErrorFunc?.Invoke($" Remove tid:{tid} in taskDic failed.");
                    return false;
                }
            }
            else
            {
                WarnFunc?.Invoke($"tid:{tid} is not exist.");
                return false;
            }
        }

        /// <summary>
        /// 重置
        /// </summary>
        public override void Reset()
        {
            taskDic.Clear();
            tidLst.Clear();
            currentFrame = 0;
        }

        /// <summary>
        /// 驱动任务
        /// </summary>
        public void UpdateTask()
        {
            ++currentFrame;
            tidLst.Clear();
            foreach (var item in taskDic)
            {
                FrameTask task = item.Value;
                if (task.destFrame <= currentFrame)
                {
                    task.taskCB.Invoke(task.tid);
                    task.destFrame += task.delay;
                    --task.count;
                    if (task.count == 0)
                        tidLst.Add(task.tid);
                }
            }

            for (int i = 0; i < tidLst?.Count; i++)
            {
                if (taskDic.Remove(tidLst[i]))
                    LogFunc?.Invoke($"Task tid:{tidLst[i]} run to completion. ");
                else
                    ErrorFunc?.Invoke($"Remove tid:{tidLst[i]} task in taskDic failed.");
            }
        }

        protected override int GenerateTid()
        {
            lock (tidlock)
            {
                while (true)
                {
                    ++tid;
                    if (tid == int.MaxValue)
                        tid = 0;
                    if (!taskDic.ContainsKey(tid))
                        return tid;
                }
            }
        }

        class FrameTask
        {
            public int tid;
            public uint delay;
            public int count;

            public Action<int> taskCB;
            public Action<int> cancelCB;

            public ulong destFrame;
            public FrameTask(
                int tid,
                uint delay,
                int count,
                ulong destFrame,
                Action<int> taskCB,
                Action<int> canceLCB)
            {
                this.tid = tid;
                this.delay = delay;
                this.count = count;
                this.taskCB = taskCB;
                this.cancelCB = canceLCB;

                this.destFrame = destFrame;
            }
        }
    }
}
