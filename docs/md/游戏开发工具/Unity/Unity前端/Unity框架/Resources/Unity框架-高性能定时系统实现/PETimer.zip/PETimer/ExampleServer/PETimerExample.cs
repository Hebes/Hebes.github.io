﻿using PETimer;
using PEUtils;

namespace ExampleServer
{
    /// <summary>
    /// PETimer案例
    /// </summary>
    class PETimerExample
    {
        /// <summary>
        /// 客户端执行的测试代码
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            LogConfig logConfig = new LogConfig();
            logConfig.loggerEnum = LoggerType.Console;
            PELog.InitSettings(logConfig);
            PELog.ColorLog(LogColor.Green, "测试");

            FrameTimerExample();

            //AsyncTimerExample();

            //TickTimerExample1();
            //TickTimerExample2();
            //TickTimerExample3();
            //TickTimerExample4();
            Console.ReadKey();
        }

        static void FrameTimerExample()
        {
            FrameTimer timer = new FrameTimer(100)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint frameNumber = 10;
            int count = 5;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                timer.AddTask(frameNumber, (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Yellow, "tid:{0} cancel.", tid);
                },
                count);

                while (true)
                {
                    timer.UpdateTask();
                    Thread.Sleep(66);
                }
            });

            while (true)
            {
                switch (Console.ReadLine())
                {
                    //case "calc":
                    //    PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                    //    break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }

        //1.独立线程驱动，驱动线程回调
        static void AsyncTimerExample()
        {
            AsyncTimer timer = new AsyncTimer(true)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint intervel = 66;
            int count = 300;
            int sum = 0;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                DateTime historyTime = DateTime.UtcNow;
                timer.AddTask(intervel, (int tid) =>
                {
                    DateTime nowTime = DateTime.UtcNow;
                    TimeSpan ts = nowTime - historyTime;
                    historyTime = nowTime;
                    int delta = (int)(ts.TotalMilliseconds - intervel);
                    PELog.ColorLog(LogColor.Yellow, $"间隔差: {delta}");
                    sum += Math.Abs(delta);
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} work.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                count);
            });

            Task.Run(() =>
            {
                while (true)
                {
                    timer.HandleTask();
                    Thread.Sleep(5);
                }
            });


            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "calc":
                        PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                        break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }


        //1.独立线程驱动，驱动线程回调
        static void TickTimerExample1()
        {
            TickTimer timer = new TickTimer(10, false)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint intervel = 66;
            int count = 50;
            int sum = 0;
            int taskID = 0;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                DateTime historyTime = DateTime.UtcNow;
                taskID = timer.AddTask(intervel, (int tid) =>
                {
                    DateTime nowTime = DateTime.UtcNow;
                    TimeSpan ts = nowTime - historyTime;
                    historyTime = nowTime;
                    int delta = (int)(ts.TotalMilliseconds - intervel);
                    PELog.ColorLog(LogColor.Yellow, $"间隔差: {delta}");
                    sum += Math.Abs(delta);
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} work.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                count);
            });

            Task.Run(async () =>
            {
                PELog.Log("HandLe Start.");
                while (true)
                {
                    //TickTimer(O, true)参数为0,true的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,true,多改变可以查看是否为多线程运行
                    //timer.HandleTask();

                    //TickTimer(O, false)参数为0,false的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,false,多改变可以查看是否为多线程运行

                    //TickTimer(1O, false)参数不为0,false的时候
                    //不需要开

                    //TickTimer(1O, true)参数不为0,true的时候,
                    //timer.HandleTask();
                    await Task.Delay(2);
                }
            });


            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "calc":
                        PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                        break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }
        //2.独立线程驱动，外部线程回调
        static void TickTimerExample2()
        {
            TickTimer timer = new TickTimer(10, true)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint intervel = 66;
            int count = 50;
            int sum = 0;
            int taskID = 0;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                DateTime historyTime = DateTime.UtcNow;
                taskID = timer.AddTask(intervel, (int tid) =>
                {
                    DateTime nowTime = DateTime.UtcNow;
                    TimeSpan ts = nowTime - historyTime;
                    historyTime = nowTime;
                    int delta = (int)(ts.TotalMilliseconds - intervel);
                    PELog.ColorLog(LogColor.Yellow, $"间隔差: {delta}");
                    sum += Math.Abs(delta);
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} work.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                count);
            });

            Task.Run(async () =>
            {
                PELog.Log("HandLe Start.");
                while (true)
                {
                    //TickTimer(O, true)参数为0,true的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,true,多改变可以查看是否为多线程运行
                    //timer.HandleTask();

                    //TickTimer(O, false)参数为0,false的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,false,多改变可以查看是否为多线程运行

                    //TickTimer(1O, false)参数不为0,false的时候
                    //不需要开

                    //TickTimer(1O, true)参数不为0,true的时候,
                    timer.HandleTask();//外部回调
                    await Task.Delay(2);
                }
            });


            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "calc":
                        PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                        break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }
        //3.外部线程区动，驱动线程回调
        static void TickTimerExample3()
        {
            TickTimer timer = new TickTimer(0, false)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint intervel = 66;
            int count = 50;
            int sum = 0;
            int taskID = 0;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                DateTime historyTime = DateTime.UtcNow;
                taskID = timer.AddTask(intervel, (int tid) =>
                {
                    DateTime nowTime = DateTime.UtcNow;
                    TimeSpan ts = nowTime - historyTime;
                    historyTime = nowTime;
                    int delta = (int)(ts.TotalMilliseconds - intervel);
                    PELog.ColorLog(LogColor.Yellow, $"间隔差: {delta}");
                    sum += Math.Abs(delta);
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} work.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                count);
            });

            Task.Run(async () =>
            {
                PELog.Log("HandLe Start.");
                while (true)
                {
                    //TickTimer(O, true)参数为0,true的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,true,多改变可以查看是否为多线程运行
                    //timer.HandleTask();

                    //TickTimer(O, false)参数为0,false的时候
                    timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,false,多改变可以查看是否为多线程运行

                    //TickTimer(1O, false)参数不为0,false的时候
                    //不需要开

                    //TickTimer(1O, true)参数不为0,true的时候,
                    //timer.HandleTask();
                    await Task.Delay(2);
                }
            });


            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "calc":
                        PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                        break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }
        //4.外部线程驱动，外部线程回调
        static void TickTimerExample4()
        {
            TickTimer timer = new TickTimer(0, true)
            {
                LogFunc = PELog.Log,
                WarnFunc = PELog.Warn,
                ErrorFunc = PELog.Error
            };

            uint intervel = 66;
            int count = 50;
            int sum = 0;
            int taskID = 0;
            Task.Run(async () =>
            {
                await Task.Delay(2000);
                DateTime historyTime = DateTime.UtcNow;
                taskID = timer.AddTask(intervel, (int tid) =>
                {
                    DateTime nowTime = DateTime.UtcNow;
                    TimeSpan ts = nowTime - historyTime;
                    historyTime = nowTime;
                    int delta = (int)(ts.TotalMilliseconds - intervel);
                    PELog.ColorLog(LogColor.Yellow, $"间隔差: {delta}");
                    sum += Math.Abs(delta);
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} work.", tid);
                },
                (int tid) =>
                {
                    PELog.ColorLog(LogColor.Magenta, "tid:{0} cancel.", tid);
                },
                count);
            });

            Task.Run(async () =>
            {
                PELog.Log("HandLe Start.");
                while (true)
                {
                    //TickTimer(O, true)参数为0,true的时候
                    timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,true,多改变可以查看是否为多线程运行
                    timer.HandleTask();

                    //TickTimer(O, false)参数为0,false的时候
                    //timer.UpdateTask();//是个是服务器的演示 new TickTimer参数改为0,false,多改变可以查看是否为多线程运行

                    //TickTimer(1O, false)参数不为0,false的时候
                    //不需要开

                    //TickTimer(1O, true)参数不为0,true的时候,
                    //timer.HandleTask();
                    await Task.Delay(2);
                }
            });


            while (true)
            {
                switch (Console.ReadLine())
                {
                    case "calc":
                        PELog.ColorLog(LogColor.Red, "平均间隔" + sum * 1.0f / count);
                        break;
                    case "del":
                        timer.DeleteTask(1);
                        break;
                }
            }
        }
    }
}
