﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IRecycleObject 
{

    void OnLoad();

    void OnRecover();

}
