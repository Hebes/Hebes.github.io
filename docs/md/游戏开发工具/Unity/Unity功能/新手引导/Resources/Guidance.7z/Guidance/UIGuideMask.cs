﻿using System;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// 新手引导遮罩层
/// </summary>
[ExecuteInEditMode, RequireComponent(typeof(Image))]
[DisallowMultipleComponent]
public class UIGuideMask : MonoBehaviour, ICanvasRaycastFilter
{
    private RectTransform canvasRT;
    private float canvasHeight;
    private Material material;
    private RectTransform targetRect;

    public Action OnClickTargetRect;

    private void Awake()
    {
        var canvas = GetComponentInParent<Canvas>();
        canvasRT = canvas.GetComponent<RectTransform>();
        canvasHeight = canvasRT.sizeDelta.y;
        var image = GetComponent<Image>();
        material = image.material;
    }

    private void OnDisable()
    {
        targetRect = null;
        OnClickTargetRect = null;
    }

    private void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Vector2 mousePosition = Input.mousePosition;
            if (ContainsScreenPoint(mousePosition))
            {
                //如果用户点击了引导区域，则调用回调函数
                //可在外部回调函数判断是否继续下一步引导
                OnClickTargetRect?.Invoke();
            }
        }
    }

    // 显示引导
    public void Show(RectTransform target, Action callback)
    {
        this.targetRect = target;
        this.OnClickTargetRect = callback;
        //获取对象的世界坐标
        Vector3[] fourCornersArray = new Vector3[4];
        target.GetWorldCorners(fourCornersArray);
        Vector3 ltPos = fourCornersArray[1];//左上角
        Vector3 rdPos = fourCornersArray[3];//右下角
        //注意：
        //C#获取到的屏幕(0,0)在左下角，
        //Shader中的屏幕(0,0)在左上角。
        ltPos = RectTransformUtility.WorldToScreenPoint(null, ltPos);
        rdPos = RectTransformUtility.WorldToScreenPoint(null, rdPos);
        //与Shader中的屏幕原点保持一致(即，Y轴反向)
        ltPos.y = canvasHeight - ltPos.y;
        rdPos.y = canvasHeight - rdPos.y;
        //裁剪区域
        Vector4 clipRect = new Vector4();
        clipRect.x = ltPos.x;
        clipRect.y = ltPos.y;
        clipRect.z = rdPos.x;
        clipRect.w = rdPos.y;
        material.SetVector("_ScreenClipRect", clipRect);
    }

    // 判断屏幕坐标点是否在目标区域内
    public bool ContainsScreenPoint(Vector2 screenPoint)
    {
        if (targetRect == null)
            return false;
        bool result = RectTransformUtility.RectangleContainsScreenPoint(targetRect, screenPoint);
        return result;
    }

    // 事件是否向下渗透
    // true:不渗透。false:渗透
    public bool IsRaycastLocationValid(Vector2 sp, Camera eventCamera)
    {
        return !ContainsScreenPoint(sp);
    }
}