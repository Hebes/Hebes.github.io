﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestGuide : MonoBehaviour
{
    public UIGuideMask guide;
    public List<RectTransform> guideList = new List<RectTransform>();

    void Start()
    {
        BeginGuide();
    }

    private void BeginGuide()
    {
        if (guideList.Count == 0)
            return;
        var rt = guideList[0];
        guideList.RemoveAt(0);
        guide.Show(rt, () =>
        {
            BeginGuide();
        });
    }
}
