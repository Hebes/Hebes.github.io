﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Client
{
    public class ClientStart
    {
        private static int port = 17333;
        private static string IP = "192.168.1.100";

        public static void Main(string[] arge)
        {
            //CreatTcpClient();
            CreatUDPClient();
            Console.ReadKey();
        }

        private static void CreatUDPClient()
        {
            UdpClient client = new UdpClient();
            byte[] data = Encoding.ASCII.GetBytes("UDPClient sned message :hello");
            IPEndPoint remoteIP = new IPEndPoint(IPAddress.Parse(IP), port);
            client.Send(data, data.Length, remoteIP);
            Console.WriteLine("Message send to remote address");

        }

        private static void CreatTcpClient()
        {
            try
            {
                var client = new TcpClient(IP, port);
                NetworkStream ns = client.GetStream();
                byte[] data = new byte[1024];
                int Len = ns.Read(data, 0, data.Length);
                Console.WriteLine(Encoding.ASCII.GetString(data, 0, Len));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

        }
    }
}