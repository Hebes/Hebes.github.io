﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets.Kcp;
using System.Text;
using System.Threading.Tasks;

namespace KCPTest
{
    public class KCPHandle : IKcpCallback
    {
        public Action<Memory<byte>> Out;

        /// <summary>
        /// kcp发送出去的数据
        /// </summary>
        /// <param name="buffer"></param>
        /// <param name="avalidLength"></param>
        public void Output(IMemoryOwner<byte> buffer, int avalidLength)
        {
            using (buffer)
            {
                Out(buffer.Memory.Slice(0, avalidLength));
            }
        }
    }
}
