﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets.Kcp;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace KCPTest
{
    public class KCPItem
    {
        public string itemName;
        public KCPHandle handle;
        public Kcp kcp;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="conv"></param>
        /// <param name="itemName">识别客户端和服务器哪个发送过来的数据</param>
        public KCPItem(uint conv, string itemName)
        {
            handle = new KCPHandle();
            kcp = new Kcp(conv, handle);

            kcp.NoDelay(1, 10, 2, 1);
            kcp.WndSize(64, 64);
            kcp.SetMtu(512);

            this.itemName = itemName;
        }

        //2.准备发送的数据进入这边也就是KCP这个部分请结合图片
        /// <summary>
        /// 需要发送的消息放入这里
        /// </summary>
        /// <param name="data"></param>
        public void InputData(Span<byte> data)
        {
            kcp.Input(data);
        }

        public void Set0utCallback(Action<Memory<byte>> itemSender)
        {
            handle.Out = itemSender;
        }


        /// <summary>
        /// 把二进制的数据放入,然后发送数据
        /// </summary>
        /// <param name="data"></param>
        public void SendMsg(byte[] data)
        {
            Console.WriteLine($" {itemName}输入数据: {GetByteString(data)}");
            kcp.Send(data.AsSpan());
        }

        /// <summary>
        /// 驱动KCP
        /// </summary>
        public void Updata()
        {
            kcp.Update(DateTime.UtcNow);
            int len;
            while ((len = kcp.PeekSize()) > 0)
            {
                var buffer = new byte[len];
                if (kcp.Recv(buffer)>=0) {
                    Console.WriteLine($"{itemName}收到数据: {GetByteString(buffer)}");
                }
            }
        }

        static string GetByteString(byte[] bytes)
        {
            string str = string.Empty;
            for (int i = 0; i < bytes.Length; i++)
            {
                str += $"\n   [{i}]:{bytes[i]}";
            }
            return str;
        }
    }
}
