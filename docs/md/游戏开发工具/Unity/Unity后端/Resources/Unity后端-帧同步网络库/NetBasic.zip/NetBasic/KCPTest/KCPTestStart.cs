﻿using System.Text;
using System;

namespace KCPTest
{
    public class KCPTestStart
    {
        static string GetByteString(byte[] bytes)
        {
            string str = string.Empty;
            for (int i = 0; i < bytes.Length; i++)
            {
                str += $"\n   [{i}]:{bytes[i]}";
            }
            return str;
        }

        public static void Main(string[] arge)
        {
            const uint conv = 123;

            Random rd = new Random();

            KCPItem kcpServer = new KCPItem(conv, "server");
            KCPItem kcpClient = new KCPItem(conv, "client");

            kcpServer.Set0utCallback((Memory<byte> buffer) =>
            {
                kcpClient.InputData(buffer.Span);
            });

            kcpClient.Set0utCallback((Memory<byte> buffer) =>
            {
                int next = rd.Next(100);
                if (next >= 95)//演示丢包率  现在是百分之95丢包
                {
                    Console.WriteLine($"Send Pkg Succ : {GetByteString(buffer.ToArray())}");
                    kcpServer.InputData(buffer.Span);
                }
                else
                {
                    Console. WriteLine("Send Pkg Miss");
                }
            });

            //1.发送data 这条数据
            byte[] data = Encoding.ASCII.GetBytes("www . qiqiker. com");
            kcpClient.SendMsg(data);

            while (true)
            {
                kcpServer.Updata();
                kcpClient.Updata();
                Thread.Sleep(10);
            }
        }
    }
}